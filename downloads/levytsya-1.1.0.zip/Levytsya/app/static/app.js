/* Levytsya front end: talks to app/server.py, which runs the four scripts. */
(function () {
  "use strict";

  const TOKEN = document.querySelector('meta[name="lev-token"]').content;
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => [...(root || document).querySelectorAll(sel)];
  const TOOLS = ["stabilize", "trim", "clean", "watermark", "subtitles"];
  const LABELS = { stabilize: "STABILIZE", trim: "TRIM", clean: "CLEAN AUDIO", watermark: "WATERMARK",
                   subtitles: "SUBTITLES" };
  const POSITIONS = ["top-left", "top", "top-right", "left", "center", "right",
                     "bottom-left", "bottom", "bottom-right"];

  // ------------------------------------------------------------ plumbing
  async function api(path, opts) {
    opts = opts || {};
    const res = await fetch(path, {
      method: opts.method || (opts.body ? "POST" : "GET"),
      headers: { "X-Levytsya-Token": TOKEN, "Content-Type": "application/json" },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || res.statusText);
    return data;
  }
  const mediaUrl = (p) => `/api/media?token=${encodeURIComponent(TOKEN)}&path=${encodeURIComponent(p)}`;

  let toastTimer = 0;
  function toast(msg, isError) {
    let el = $(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; document.body.append(el); }
    el.textContent = msg;
    el.classList.toggle("error", !!isError);
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, isError ? 6000 : 2500);
    if (isError) sfx("error");
  }

  /* path boxes are right-to-left so long paths keep their end visible; the
     invisible LRM marks stop punctuation from jumping to the wrong side */
  const showPath = (sel, text) => { $(sel).textContent = "\u200E" + text + "\u200E"; $(sel).title = text; };

  /* retro replacement for prompt()/confirm(): resolves to the text (or true) on OK, null on cancel */
  function ask(title, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      const d = $("#ask"), input = $("#ask-input");
      const wantsText = opts.value !== undefined;
      $("#ask-title").textContent = title;
      $("#ask-text").textContent = opts.text || "";
      $("#ask-text").hidden = !opts.text;
      input.hidden = !wantsText;
      input.value = wantsText ? opts.value : "";
      $("#ask-ok").textContent = opts.ok || "OK";
      $("#ask-ok").className = `btn small ${opts.danger ? "red" : "go"}`;
      // answer from submit/cancel directly: the dialog's "close" event can be
      // deferred indefinitely while the page is in a background tab
      const form = $("form", d);
      const finish = (ok) => {
        form.onsubmit = d.oncancel = null;
        d.close();
        resolve(!ok ? null : wantsText ? input.value.trim() : true);
      };
      form.onsubmit = (e) => { e.preventDefault(); finish(e.submitter ? e.submitter.value === "ok" : true); };
      d.oncancel = (e) => { e.preventDefault(); finish(false); };
      d.showModal();
      if (wantsText) { input.focus(); input.select(); } else $("#ask-ok").focus();
    });
  }

  const store = {
    get(key, fallback) {
      try { const v = localStorage.getItem("lev." + key); return v === null ? fallback : JSON.parse(v); }
      catch (e) { return fallback; }
    },
    set(key, value) { try { localStorage.setItem("lev." + key, JSON.stringify(value)); } catch (e) { /* private mode */ } },
  };

  // ------------------------------------------------------------ 8-bit sound
  let audioCtx = null;
  let soundOn = store.get("sound", true);
  function sfx(kind) {
    if (!soundOn) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const notes = { hop: [[660, 0.05]], ok: [[523, 0.08], [784, 0.12]],
                      error: [[220, 0.12], [150, 0.2]],
                      home: [[523, 0.1], [659, 0.1], [784, 0.1], [1047, 0.25]] }[kind] || [];
      let t = audioCtx.currentTime;
      notes.forEach(([f, d]) => {
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = "square"; o.frequency.value = f;
        g.gain.setValueAtTime(0.06, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
        o.connect(g).connect(audioCtx.destination); o.start(t); o.stop(t + d);
        t += d;
      });
    } catch (e) { /* no audio */ }
  }
  function renderSound() { $("#sound-btn").textContent = soundOn ? "SOUND ON" : "SOUND OFF"; }
  $("#sound-btn").addEventListener("click", () => { soundOn = !soundOn; store.set("sound", soundOn); renderSound(); sfx("ok"); });
  renderSound();

  // ------------------------------------------------------------ time helpers (same rules as trim.py)
  function parseTime(text) {
    text = String(text || "").trim();
    if (!text) return null;
    const parts = text.split(":").map(Number);
    if (parts.length > 3 || parts.some((p) => !isFinite(p) || p < 0)) return NaN;
    return parts.reduce((acc, p) => acc * 60 + p, 0);
  }
  function fmtTime(s, short) {
    if (s == null || !isFinite(s)) return "--:--";
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    const ss = short ? String(Math.floor(sec)).padStart(2, "0") : sec.toFixed(2).padStart(5, "0");
    return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + ss;
  }

  // ------------------------------------------------------------ scores
  let score = 0;
  const renderScores = () => {
    $("#score").textContent = String(score).padStart(5, "0");
    $("#hiscore").textContent = String(Math.max(score, store.get("hiscore", 0))).padStart(5, "0");
  };
  function addScore(points) {
    score += points;
    if (score > store.get("hiscore", 0)) store.set("hiscore", score);
    renderScores();
  }
  renderScores();
  Levytsya.mountLioness($("#logo-sprite"), 3);
  Levytsya.mountLioness($("#mascot-sprite"), 4);
  Levytsya.mountLioness($("#title-sprite"), 8);

  // the lioness talks in her speech bubble, like the жаба frog
  function say(text) {
    $("#bubble").textContent = text;
    const sprite = $("#mascot-sprite");
    sprite.classList.remove("talk");
    void sprite.offsetWidth; // restart the animation
    sprite.classList.add("talk");
  }

  // title screen: any key or click starts
  const title = $("#title-screen");
  function startGame() {
    if (title.hidden) return;
    title.hidden = true;
    sfx("ok");
    window.removeEventListener("keydown", startGame);
  }
  title.addEventListener("click", startGame);
  window.addEventListener("keydown", startGame);
  title.focus();
  const attract = Levytsya.LevBoard($("#attract"), [
    { style: "demo1", label: "STABILIZE" }, { style: "trim", label: "TRIM" },
    { style: "demo2", label: "CLEAN" }, { style: "watermark", label: "WATERMARK" },
    { style: "subtitles", label: "SUBTITLES" },
  ], { demo: true, scale: 2 });

  // ------------------------------------------------------------ health
  let health = {};
  async function checkHealth() {
    try { health = await api("/api/health"); }
    catch (e) { return block("SERVER NOT RESPONDING", "Start Levytsya again with run.py, then reload this page."); }
    if (!health.ffmpeg || !health.ffprobe) {
      block("INSERT FFMPEG TO CONTINUE",
        "Levytsya needs ffmpeg. Install it, then reload this page:\n\n" +
        "  macOS:    brew install ffmpeg\n  Windows:  winget install ffmpeg\n  Linux:    sudo apt install ffmpeg");
    }
    if (!health.opencv) disableLevel("stabilize", "OpenCV is missing: run Levytsya with run.py to install it.");
    if (!health.pillow) disableLevel("watermark", "Pillow is missing: run Levytsya with run.py to install it.");
    setupSubtitles();
  }
  function block(title, text) {
    const el = $("#blocker");
    el.innerHTML = "";
    const h = document.createElement("h2"); h.textContent = title;
    const pre = document.createElement("pre"); pre.textContent = text;
    el.append(h, pre);
    el.hidden = false;
  }
  function disableLevel(tool, why) {
    const card = $(`.level[data-tool="${tool}"]`);
    const sw = $("[data-enable]", card);
    sw.checked = false; sw.disabled = true;
    const p = document.createElement("p"); p.className = "help red"; p.textContent = why;
    $(".level-head", card).after(p);
    syncLevels();
  }

  // ------------------------------------------------------------ file browser
  const dlg = $("#browser");
  let browse = null;
  function openBrowser(opts) {
    return new Promise((resolve) => {
      browse = { ...opts, resolve };
      $("#browser-title").textContent = opts.title;
      $("#save-row").hidden = opts.mode !== "save";
      $("#save-name").value = opts.name || "";
      $("#sort").value = store.get("browseSort", "name");
      dlg.showModal();
      $("#find").focus();
      loadDir(opts.start || store.get("lastDir", ""));
    });
  }
  dlg.addEventListener("close", () => { if (browse) { browse.resolve(null); browse = null; } });
  function finishBrowse(path) {
    const b = browse; browse = null; dlg.close(); if (b) b.resolve(path);
  }
  async function loadDir(path) {
    let data;
    try {
      data = await api(`/api/ls?path=${encodeURIComponent(path || "")}&kinds=${(browse && browse.kinds || []).join(",")}`);
    } catch (e) { return toast(e.message, true); }
    browse.dir = data.path;
    showPath("#browser-path", data.path);
    $("#up-btn").disabled = !data.parent;
    $("#up-btn").onclick = () => loadDir(data.parent);
    $("#places").replaceChildren(...data.places.map((p) => {
      const b = document.createElement("button"); b.type = "button"; b.textContent = p.name; b.title = p.path;
      b.onclick = () => loadDir(p.path); return b;
    }));
    browse.entries = data.entries;
    $("#find").value = "";
    renderEntries();
  }
  /* folders always stay on top; the sort and search only reorder/filter within each group */
  const SORTS = {
    name: (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" }),
    "name-desc": (a, b) => SORTS.name(b, a),
    new: (a, b) => (b.mtime || 0) - (a.mtime || 0),
    old: (a, b) => (a.mtime || 0) - (b.mtime || 0),
    big: (a, b) => a.size - b.size ? b.size - a.size : SORTS.name(a, b),
    small: (a, b) => a.size - b.size ? a.size - b.size : SORTS.name(a, b),
  };
  const fmtDate = (t) => t ? new Date(t * 1000).toLocaleDateString(undefined,
    { year: "numeric", month: "short", day: "numeric" }) : "";
  function shownEntries() {
    const q = $("#find").value.trim().toLowerCase();
    const sort = SORTS[$("#sort").value] || SORTS.name;
    return browse.entries.filter((e) => !q || e.name.toLowerCase().includes(q))
      .sort((a, b) => (b.dir - a.dir) || sort(a, b));
  }
  function pickEntry(e) {
    if (e.dir) return loadDir(e.path);
    if (browse.mode === "save") { $("#save-name").value = e.name; return; }
    store.set("lastDir", browse.dir);
    finishBrowse(e.path);
  }
  function renderEntries() {
    const q = $("#find").value.trim();
    const items = shownEntries().map((e) => {
      const li = document.createElement("li"); li.className = e.dir ? "dir" : "file";
      const b = document.createElement("button"); b.type = "button";
      const name = document.createElement("span"); name.textContent = (e.dir ? "▸ " : "") + e.name;
      const size = document.createElement("span"); size.className = "size";
      size.textContent = [e.dir ? "" : (e.size / 1048576).toFixed(1) + " MB", fmtDate(e.mtime)]
        .filter(Boolean).join("  ·  ");
      b.append(name, size);
      b.onclick = () => pickEntry(e);
      li.append(b); return li;
    });
    if (!items.length) {
      const li = document.createElement("li"); li.className = "empty";
      li.textContent = q ? `Nothing here matches "${q}".`
        : browse.mode === "save" ? "Empty folder: type a name below." : "Nothing playable here.";
      items.push(li);
    }
    $("#entries").replaceChildren(...items);
    $("#entries").scrollTop = 0;
  }
  $("#find").addEventListener("input", () => { if (browse && browse.entries) renderEntries(); });
  /* Enter would submit the dialog form and close it: open the top match instead */
  $("#find").addEventListener("keydown", (ev) => {
    if (ev.key !== "Enter") return;
    ev.preventDefault();
    const first = browse && browse.entries && shownEntries()[0];
    if (first) pickEntry(first);
  });
  $("#sort").addEventListener("change", () => {
    store.set("browseSort", $("#sort").value);
    if (browse && browse.entries) renderEntries();
  });
  $("#save-here").addEventListener("click", () => {
    const name = $("#save-name").value.trim();
    if (!name) return toast("Type a file name", true);
    const sep = browse.dir.includes("\\") ? "\\" : "/";
    finishBrowse(browse.dir.replace(/[\\/]$/, "") + sep + name);
  });

  // ------------------------------------------------------------ input video
  const video = $("#video");
  let input = null;
  async function setInput(path, quiet) {
    let info;
    try { info = await api(`/api/probe?path=${encodeURIComponent(path)}`); }
    catch (e) { return quiet ? null : toast(e.message, true); }
    if (!info.has_video) return toast("This file has no video stream", true);
    input = info;
    store.set("lastInput", path);
    showPath("#input-path", path);
    $("#input-meta").textContent =
      `${info.width}×${info.height} · ${fmtTime(info.duration, true)} · ${Math.round(info.fps)} FPS · ` +
      `${(info.vcodec || "?").toUpperCase()} · ${info.has_audio ? "AUDIO ✓" : "NO AUDIO"}`;
    video.src = mediaUrl(path);
    $("#screen-empty").hidden = true;
    attract.destroy();
    const dot = path.lastIndexOf("."), base = dot > 0 ? path.slice(0, dot) : path;
    $("#output-path").value = base + "_levytsya.mp4";
    $("#wm-preview").hidden = true;
    $("#audio-ab").hidden = true;
    sfx("ok");
    say(`NICE CLIP: ${fmtTime(info.duration, true)} OF VIDEO. TURN ON THE LEVELS YOU WANT, THEN PRESS START.`);
    trimChanged(false, true);
    validate();
  }
  video.addEventListener("error", () => {
    if (input) toast("The browser can't play this file, but Levytsya can still process it. Type times by hand.", true);
  });
  // Chrome may defer loading media in a background tab; kick it when the tab shows
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && input && video.readyState === 0) video.load();
  });
  $("#pick-input").addEventListener("click", async () => {
    const p = await openBrowser({ title: "CHOOSE VIDEO", kinds: ["video"] });
    if (p) setInput(p);
  });
  const now = () => video.currentTime || 0;
  function tick() {
    $("#clock").textContent = fmtTime(now());
    drawTimeline();
  }
  video.addEventListener("timeupdate", tick);
  video.addEventListener("seeked", tick);

  // ------------------------------------------------------------ levels: toggles and sliders
  const saved = store.get("levels", {});
  function syncLevels() {
    $$(".level").forEach((card) => card.classList.toggle("off", !$("[data-enable]", card).checked));
    validate();
  }
  $$(".level").forEach((card) => {
    const tool = card.dataset.tool;
    const s = saved[tool] || {};
    const sw = $("[data-enable]", card);
    if (s.enabled !== undefined) sw.checked = s.enabled;
    sw.addEventListener("change", () => { sfx("hop"); syncLevels(); persist(); });
    $$("[data-opt]", card).forEach((el) => {
      const key = el.dataset.opt;
      if (s[key] !== undefined) {
        if (el.type === "checkbox") el.checked = s[key]; else el.value = s[key];
      }
      const out = $(`[data-out="${key}"]`, card);
      const show = () => {
        if (!out) return;
        out.textContent = key === "crop" ? Math.round(el.value * 100) + "%"
          : key === "strength" ? Math.round(el.value * 100) + "%" : el.value;
      };
      el.addEventListener("input", () => { show(); persist(); });
      el.addEventListener("change", persist);
      show();
    });
  });
  function levelOptions(tool) {
    const card = $(`.level[data-tool="${tool}"]`);
    const o = {};
    $$("[data-opt]", card).forEach((el) => {
      const numeric = el.type === "range" || (el.tagName === "SELECT" && el.value !== "" && !isNaN(el.value));
      o[el.dataset.opt] = el.type === "checkbox" ? el.checked : numeric ? Number(el.value) : el.value;
    });
    return o;
  }
  const enabled = (tool) => $(`.level[data-tool="${tool}"] [data-enable]`).checked;
  function persist() {
    const out = {};
    TOOLS.forEach((t) => { out[t] = { enabled: enabled(t), ...levelOptions(t) }; });
    store.set("levels", out);
    store.set("trim", trim);
    store.set("wm", wm);
  }

  // ------------------------------------------------------------ level 2: trim
  const trim = store.get("trim", { start: "", end: "", cuts: [] });
  let pendingCut = null;
  function keepSegments() {
    const dur = input ? input.duration : 0;
    let start = parseTime(trim.start), end = parseTime(trim.end);
    if (start == null || isNaN(start)) start = 0;
    if (end == null || isNaN(end) || end > dur) end = dur;
    const cuts = trim.cuts.map((c) => [parseTime(c.a), parseTime(c.b)])
      .filter(([a, b]) => a != null && b != null && !isNaN(a) && !isNaN(b) && b > a)
      .sort((x, y) => x[0] - y[0]);
    const merged = [];
    cuts.forEach(([a, b]) => {
      a = Math.max(a, start); b = Math.min(b, end);
      if (b <= a) return;
      if (merged.length && a <= merged[merged.length - 1][1]) merged[merged.length - 1][1] = Math.max(merged[merged.length - 1][1], b);
      else merged.push([a, b]);
    });
    const keep = []; let pos = start;
    merged.forEach(([a, b]) => { if (a > pos) keep.push([pos, a]); pos = b; });
    if (end > pos) keep.push([pos, end]);
    return { keep, start, end };
  }
  function trimErrors() {
    const errs = [];
    [["START", trim.start], ["END", trim.end]].forEach(([n, v]) => { if (isNaN(parseTime(v))) errs.push(`${n} is not a time`); });
    trim.cuts.forEach((c, i) => {
      const a = parseTime(c.a), b = parseTime(c.b);
      if (a == null || b == null || isNaN(a) || isNaN(b)) errs.push(`Cut ${i + 1} needs two times`);
      else if (b <= a) errs.push(`Cut ${i + 1} ends before it starts`);
    });
    return errs;
  }
  function renderTrim() {
    $("#trim-start").value = trim.start;
    $("#trim-end").value = trim.end;
    $("#cuts").replaceChildren(...trim.cuts.map((c, i) => {
      const row = document.createElement("div"); row.className = "cut";
      const lab = document.createElement("span"); lab.textContent = `CUT${i + 1}`;
      const a = document.createElement("input"); a.type = "text"; a.value = c.a; a.placeholder = "from"; a.setAttribute("aria-label", `Cut ${i + 1} from`);
      const dash = document.createElement("span"); dash.textContent = "TO";
      const b = document.createElement("input"); b.type = "text"; b.value = c.b; b.placeholder = "to"; b.setAttribute("aria-label", `Cut ${i + 1} to`);
      const del = document.createElement("button"); del.className = "link"; del.textContent = "×"; del.title = "Remove this cut";
      a.oninput = () => { c.a = a.value; trimChanged(false); };
      b.oninput = () => { c.b = b.value; trimChanged(false); };
      del.onclick = () => { trim.cuts.splice(i, 1); trimChanged(true); };
      row.append(lab, a, dash, b, del);
      return row;
    }));
    trimChanged(false, true);
  }
  function trimChanged(rerender, skipPersist) {
    if (rerender) return renderTrim();
    const errs = trimErrors();
    if (errs.length) {
      $("#trim-result").textContent = errs[0].toUpperCase();
      $("#trim-result").className = "result red";
    } else if (input) {
      const { keep } = keepSegments();
      const total = keep.reduce((acc, [a, b]) => acc + b - a, 0);
      $("#trim-result").textContent = `RESULT ${fmtTime(total)} (−${fmtTime(input.duration - total)})`;
      $("#trim-result").className = "result";
    } else $("#trim-result").textContent = "";
    drawTimeline();
    validate();
    if (!skipPersist) persist();
  }
  function drawTimeline() {
    const c = $("#timeline");
    const w = c.clientWidth || 300;
    if (c.width !== w) c.width = w;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#000"; ctx.fillRect(0, 0, c.width, c.height);
    if (!input || !input.duration) return;
    const x = (t) => (t / input.duration) * c.width;
    ctx.fillStyle = "#3a0000"; ctx.fillRect(0, 6, c.width, 24);
    ctx.fillStyle = "#ff2a2a";
    for (let i = 0; i < c.width; i += 6) ctx.fillRect(i, 6 + (i / 6 % 2) * 12, 3, 3);
    keepSegments().keep.forEach(([a, b]) => {
      ctx.fillStyle = "#21d221"; ctx.fillRect(x(a), 6, Math.max(x(b) - x(a), 1), 24);
      ctx.fillStyle = "#126b12"; ctx.fillRect(x(a), 24, Math.max(x(b) - x(a), 1), 6);
    });
    if (pendingCut != null) { ctx.fillStyle = "#ff4fd8"; ctx.fillRect(x(pendingCut) - 1, 0, 3, 36); }
    ctx.fillStyle = "#ffd800"; ctx.fillRect(x(now()) - 1, 0, 3, 36);
  }
  $("#timeline").addEventListener("click", (e) => {
    if (!input) return;
    const r = e.currentTarget.getBoundingClientRect();
    video.currentTime = ((e.clientX - r.left) / r.width) * input.duration;
  });
  const needInput = () => { if (!input) { toast("Choose a video first", true); return true; } return false; };
  $("#set-start").addEventListener("click", () => { if (needInput()) return; trim.start = fmtTime(now()); sfx("hop"); renderTrim(); });
  $("#set-end").addEventListener("click", () => { if (needInput()) return; trim.end = fmtTime(now()); sfx("hop"); renderTrim(); });
  $("#cut-in").addEventListener("click", () => {
    if (needInput()) return;
    pendingCut = now();
    $("#cut-pending").textContent = `CUT FROM ${fmtTime(pendingCut)} · NOW MOVE TO THE END AND PRESS "CUT TO"`;
    $("#cut-pending").hidden = false;
    say('NOW MOVE TO WHERE THE CUT ENDS AND PRESS "< CUT TO".');
    sfx("hop"); drawTimeline();
  });
  $("#cut-out").addEventListener("click", () => {
    if (needInput()) return;
    if (pendingCut == null) return toast('Press "CUT FROM" first', true);
    let a = pendingCut, b = now();
    if (b < a) [a, b] = [b, a];
    if (b - a < 0.05) return toast("The cut is too short", true);
    trim.cuts.push({ a: fmtTime(a), b: fmtTime(b) });
    trim.cuts.sort((x, y) => (parseTime(x.a) || 0) - (parseTime(y.a) || 0));
    pendingCut = null; $("#cut-pending").hidden = true;
    say(`CHOMP! ${fmtTime(b - a)} REMOVED. THE OTHER TIMES DON'T MOVE.`);
    sfx("ok"); renderTrim();
  });
  $("#add-cut").addEventListener("click", () => { trim.cuts.push({ a: "", b: "" }); renderTrim(); });
  $("#trim-start").addEventListener("input", (e) => { trim.start = e.target.value; trimChanged(false); });
  $("#trim-end").addEventListener("input", (e) => { trim.end = e.target.value; trimChanged(false); });
  window.addEventListener("resize", drawTimeline);

  // ------------------------------------------------------------ level 3: audio test
  $("#test-audio").addEventListener("click", async (e) => {
    if (needInput()) return;
    if (!input.has_audio) return toast("This video has no audio", true);
    const btn = e.currentTarget, label = btn.textContent;
    btn.disabled = true; btn.textContent = "CLEANING…";
    try {
      const r = await api("/api/preview/audio", { body: { input: input.path, start: now(), duration: 30, options: levelOptions("clean") } });
      $("#audio-before").src = mediaUrl(r.before);
      $("#audio-after").src = mediaUrl(r.after);
      $("#audio-ab").hidden = false;
      say("LISTEN TO BEFORE AND AFTER. VOICE TOO METALLIC? LOWER THE STRENGTH AND TEST AGAIN.");
      sfx("ok");
    } catch (err) { toast(err.message, true); }
    btn.disabled = false; btn.textContent = label;
  });

  // ------------------------------------------------------------ level 4: watermark
  const WM_DEFAULTS = {
    logo: { path: null, size: 0.15, angle: 0, position: "bottom-right", margin: 0.03, opacity: 0.85 },
    text: { content: null, size: 0.05, angle: 0, position: "bottom-left", margin: 0.03, opacity: 0.85,
            font: null, color: "#FFFFFF", outline: 0.08, outline_color: "#000000" },
  };
  let wm = mergeWm(store.get("wm", null));
  function mergeWm(src) {
    src = src || {};
    const out = { logo: { ...WM_DEFAULTS.logo, ...(src.logo || {}) }, text: { ...WM_DEFAULTS.text, ...(src.text || {}) },
                  logoOn: src.logoOn, textOn: src.textOn };
    if (out.logoOn === undefined) out.logoOn = !!out.logo.path;
    if (out.textOn === undefined) out.textOn = !!out.text.content;
    out.lastText = src.lastText || out.text.content || "";
    return out;
  }
  const getPath = (path) => path.split(".").reduce((o, k) => o[k], wm);
  function setPath(path, value) { const [a, b] = path.split("."); wm[a][b] = value; }
  function toHex(color) {
    const m = String(color || "").match(/^#?([0-9a-f]{6})$/i);
    if (m) return "#" + m[1];
    const map = { white: "#ffffff", black: "#000000", red: "#ff0000", yellow: "#ffff00" };
    return map[String(color).toLowerCase()] || "#ffffff";
  }
  function fmtW(path, v) {
    if (path.endsWith("angle")) return v + "°";
    if (path.endsWith("opacity") || path.endsWith(".size") || path.endsWith("margin") || path.endsWith("outline"))
      return Math.round(v * 1000) / 10 + "%";
    return v;
  }
  function renderWm() {
    $("#logo-on").checked = wm.logoOn;
    $("#text-on").checked = wm.textOn;
    showPath("#logo-path", wm.logo.path || "none");
    showPath("#font-path", wm.text.font || "Helvetica Neue");
    $$("[data-w]").forEach((el) => {
      const p = el.dataset.w;
      let v = p === "text.content" ? wm.lastText : getPath(p);
      if (el.type === "color") v = toHex(v);
      el.value = v == null ? "" : v;
      const out = $(`[data-wout="${p}"]`);
      if (out) out.textContent = fmtW(p, v);
    });
    $$(".pos").forEach(renderPos);
  }
  function renderPos(box) {
    const which = box.dataset.pos;
    const pos = wm[which].position;
    const named = POSITIONS.includes(pos);
    const [cx, cy] = named ? [null, null] : String(pos).split(",").map(Number);
    box.innerHTML = "";
    const grid = document.createElement("div"); grid.className = "pos-grid";
    POSITIONS.forEach((p) => {
      const b = document.createElement("button"); b.type = "button"; b.title = p; b.setAttribute("aria-label", `${which} ${p}`);
      if (p === pos) b.classList.add("on");
      b.onclick = () => { wm[which].position = p; renderPos(box); persist(); sfx("hop"); };
      grid.append(b);
    });
    const custom = document.createElement("div"); custom.className = "custom";
    ["X", "Y"].forEach((axis, i) => {
      const lab = document.createElement("label");
      const val = named ? (i === 0 ? [0, .5, 1][POSITIONS.indexOf(pos) % 3] : [0, .5, 1][Math.floor(POSITIONS.indexOf(pos) / 3)]) : (i ? cy : cx);
      lab.textContent = `${axis} ${Math.round(val * 100)}%`;
      const r = document.createElement("input"); r.type = "range"; r.min = 0; r.max = 1; r.step = 0.01; r.value = val;
      r.setAttribute("aria-label", `${which} position ${axis}`);
      r.oninput = () => {
        const xs = $$("input", custom).map((el) => Number(el.value).toFixed(2));
        wm[which].position = xs.join(",");
        $$("label", custom).forEach((l, j) => { l.textContent = `${"XY"[j]} ${Math.round(xs[j] * 100)}%`; });
        $$("button", grid).forEach((btn) => btn.classList.remove("on"));
        persist();
      };
      custom.append(lab, r);
    });
    const cap = document.createElement("label"); cap.textContent = "POSITION";
    box.append(cap, grid, custom);
  }
  $$("[data-w]").forEach((el) => {
    const p = el.dataset.w;
    el.addEventListener("input", () => {
      let v = el.value;
      if (el.type === "range") v = Number(v);
      if (p === "text.content") { wm.lastText = v; if (v.trim()) { wm.textOn = true; $("#text-on").checked = true; } }
      else setPath(p, v);
      const out = $(`[data-wout="${p}"]`);
      if (out) out.textContent = fmtW(p, v);
      persist();
    });
  });
  $("#logo-on").addEventListener("change", (e) => { wm.logoOn = e.target.checked; persist(); });
  $("#text-on").addEventListener("change", (e) => { wm.textOn = e.target.checked; persist(); });
  $("#pick-logo").addEventListener("click", async () => {
    const p = await openBrowser({ title: "CHOOSE LOGO", kinds: ["image"] });
    if (p) { wm.logo.path = p; wm.logoOn = true; renderWm(); persist(); }
  });
  $("#pick-font").addEventListener("click", async () => {
    const p = await openBrowser({ title: "CHOOSE FONT", kinds: ["font"], start: "/System/Library/Fonts" });
    if (p) { wm.text.font = p; renderWm(); persist(); }
  });
  $("#font-reset").addEventListener("click", () => { wm.text.font = null; renderWm(); persist(); });

  /* settings in the same JSON format as watermark.py --template */
  function wmSettings() {
    return {
      logo: { ...wm.logo, path: wm.logoOn ? wm.logo.path : null },
      text: { ...wm.text, content: wm.textOn && wm.lastText.trim() ? wm.lastText : null },
    };
  }
  function wmProblem() {
    const s = wmSettings();
    if (!s.logo.path && !s.text.content) return "Watermark: choose a logo or type a text";
    return null;
  }
  $("#wm-preview-btn").addEventListener("click", async (e) => {
    if (needInput()) return;
    const problem = wmProblem();
    if (problem) return toast(problem, true);
    const btn = e.currentTarget, label = btn.textContent;
    btn.disabled = true; btn.textContent = "RENDERING…";
    try {
      const r = await api("/api/preview/watermark", { body: { input: input.path, at: now(), settings: wmSettings() } });
      $("#wm-preview-img").src = mediaUrl(r.image);
      $("#wm-preview").hidden = false;
      $("#wm-preview").scrollIntoView({ behavior: "smooth", block: "nearest" });
      say("HOW DOES IT LOOK? SAVE IT AS A TEMPLATE TO REUSE IT ON EVERY VIDEO.");
      sfx("ok");
    } catch (err) { toast(err.message, true); }
    btn.disabled = false; btn.textContent = label;
  });
  $("#wm-preview-close").addEventListener("click", () => { $("#wm-preview").hidden = true; });

  async function loadTemplateList(select) {
    try {
      const names = await api("/api/templates");
      const sel = $("#tpl-select");
      sel.replaceChildren(new Option("TEMPLATE…", ""), ...names.map((n) => new Option(n, n)));
      if (select) sel.value = select;
    } catch (e) { toast(e.message, true); }
  }
  $("#tpl-load").addEventListener("click", async () => {
    const name = $("#tpl-select").value;
    if (!name) return toast("Pick a template first", true);
    try {
      const t = await api(`/api/templates/${encodeURIComponent(name)}`);
      wm = mergeWm({ ...t, logoOn: !!(t.logo && t.logo.path), textOn: !!(t.text && t.text.content),
                     lastText: (t.text && t.text.content) || "" });
      renderWm(); persist(); sfx("ok");
      toast(`Loaded "${name}"`);
    } catch (e) { toast(e.message, true); }
  });
  $("#tpl-save").addEventListener("click", async () => {
    const problem = wmProblem();
    if (problem) return toast(problem, true);
    const name = await ask("SAVE TEMPLATE", { text: "Name this watermark template. Saving with an existing name replaces it.",
                                              value: $("#tpl-select").value || "My brand", ok: "SAVE" });
    if (!name) return;
    try {
      const r = await api("/api/templates", { body: { name, settings: wmSettings() } });
      await loadTemplateList(name);
      sfx("ok");
      toast(`Saved. Also usable from the terminal: --template "${r.path}"`);
    } catch (e) { toast(e.message, true); }
  });
  $("#tpl-delete").addEventListener("click", async () => {
    const name = $("#tpl-select").value;
    if (!name) return toast("Pick a template first", true);
    if (!(await ask("DELETE TEMPLATE", { text: `Delete "${name}"? This can't be undone.`, ok: "DELETE", danger: true }))) return;
    try { await api(`/api/templates/${encodeURIComponent(name)}`, { method: "DELETE" }); await loadTemplateList(); toast("Deleted"); }
    catch (e) { toast(e.message, true); }
  });

  // ------------------------------------------------------------ level 5: subtitles
  let subLangs = store.get("subLangs", []);
  function setupSubtitles() {
    const langs = health.languages || [];
    const src = $("#sub-source");
    const savedSrc = (store.get("levels", {}).subtitles || {}).source || "";
    src.replaceChildren(new Option("Auto-detect", ""), ...langs.map(([c, n]) => new Option(n, c)));
    src.value = savedSrc;
    $("#sub-langs").replaceChildren(...langs.map(([code, name]) => {
      const lab = document.createElement("label"); lab.className = "check";
      const box = document.createElement("input"); box.type = "checkbox"; box.value = code;
      box.checked = subLangs.includes(code);
      box.onchange = () => {
        subLangs = $$("#sub-langs input:checked").map((b) => b.value);
        store.set("subLangs", subLangs); renderSubCount(); validate();
      };
      lab.append(box, document.createTextNode(` ${name}`));
      return lab;
    }));
    renderSubCount();
    renderEngine(health.subtitles_engine ? "done" : "missing");
  }
  function renderSubCount() {
    $("#sub-count").textContent = subLangs.length ? `${subLangs.length} SELECTED` : "NONE";
  }
  function renderEngine(state, log) {
    $("#engine-box").hidden = state === "done";
    $("#engine-install").disabled = state === "running";
    $("#engine-state").textContent = { running: "INSTALLING… (A FEW MINUTES)", error: "INSTALL FAILED: SEE LOG", missing: "" }[state] || "";
    if (log && log.length) { $("#engine-log").hidden = false; $("#engine-log").textContent = log.join("\n"); $("#engine-log").scrollTop = 1e9; }
    health.subtitles_engine = state === "done";
    validate();
  }
  $("#engine-install").addEventListener("click", async () => {
    try {
      let e = await api("/api/engine/install", { body: {} });
      say("INSTALLING THE TRANSCRIPTION ENGINE. GRAB A COFFEE, THIS HAPPENS ONLY ONCE.");
      renderEngine(e.state, e.log);
      const t = setInterval(async () => {
        e = await api("/api/engine").catch(() => e);
        renderEngine(e.state, e.log);
        if (e.state !== "running") {
          clearInterval(t);
          if (e.state === "done") { sfx("home"); say("ENGINE READY! SUBTITLES UNLOCKED."); } else sfx("error");
        }
      }, 1500);
    } catch (err) { toast(err.message, true); }
  });

  // ------------------------------------------------------------ output and start
  $("#pick-output").addEventListener("click", async () => {
    const cur = $("#output-path").value;
    const cut = Math.max(cur.lastIndexOf("/"), cur.lastIndexOf("\\"));
    const p = await openBrowser({ title: "SAVE AS", kinds: ["video"], mode: "save",
                                  start: cut > 0 ? cur.slice(0, cut) : "", name: cut >= 0 ? cur.slice(cut + 1) : "output.mp4" });
    if (p) { $("#output-path").value = p; validate(); }
  });
  $("#output-path").addEventListener("input", validate);

  function problems() {
    const out = [];
    if (!input) out.push("Choose a video.");
    const on = TOOLS.filter(enabled);
    if (!on.length) out.push("Turn on at least one level.");
    if (on.includes("trim")) out.push(...trimErrors());
    if (on.includes("clean") && input && !input.has_audio) out.push("This video has no audio: turn off CLEAN AUDIO.");
    if (on.includes("watermark") && wmProblem()) out.push(wmProblem());
    if (on.includes("subtitles") && !health.subtitles_engine) out.push("Subtitles: install the engine first (Level 5).");
    if (on.includes("subtitles") && input && !input.has_audio) out.push("This video has no audio: turn off SUBTITLES.");
    const outPath = $("#output-path").value.trim();
    if (input && !/\.(mp4|mov|mkv|m4v)$/i.test(outPath)) out.push("Output must end in .mp4, .mov or .mkv");
    if (input && outPath === input.path) out.push("Output must be different from the input.");
    return out;
  }
  function validate() {
    const p = problems();
    $("#start-btn").disabled = p.length > 0;
    $("#start-help").textContent = p.length ? p[0] : `${TOOLS.filter(enabled).length} level(s) ready. Good luck!`;
    $("#start-help").className = "help center" + (p.length ? "" : " green");
  }
  // watermark inputs don't call validate directly
  document.addEventListener("input", validate);
  document.addEventListener("change", validate);

  $("#start-btn").addEventListener("click", async () => {
    const stages = TOOLS.filter(enabled).map((tool) => {
      if (tool === "trim") return { tool, options: { start: trim.start, end: trim.end, cuts: trim.cuts.map((c) => `${c.a}-${c.b}`) } };
      if (tool === "watermark") return { tool, options: { settings: wmSettings() } };
      if (tool === "subtitles") return { tool, options: { ...levelOptions(tool), languages: subLangs } };
      return { tool, options: levelOptions(tool) };
    });
    try {
      const job = await api("/api/run", { body: { input: input.path, output: $("#output-path").value.trim(), stages } });
      video.pause();
      sfx("ok");
      say("WISH ME LUCK! ONE LANE PER LEVEL.");
      openGame(job);
    } catch (e) { toast(e.message, true); }
  });

  // ------------------------------------------------------------ the game screen
  const game = $("#game");
  let board = null, poll = 0, lastStage = -1;
  game.addEventListener("cancel", (e) => e.preventDefault()); // Esc doesn't hide a running job
  function openGame(job) {
    if (board) board.destroy();
    board = Levytsya.LevBoard($("#board"), job.stages.map((t) => ({ style: t, label: LABELS[t] })),
                              { scale: 3, onHop: () => sfx("hop") });
    lastStage = -1;
    $("#game-actions").replaceChildren(button("ABORT", "red", abort));
    $("#game-log").textContent = "";
    $("#game-status").className = "";
    if (!game.open) game.showModal();
    update(job);
    clearInterval(poll);
    poll = setInterval(async () => {
      try { const j = await api("/api/job"); if (j) update(j); } catch (e) { /* server busy */ }
    }, 600);
  }
  function button(text, cls, fn) {
    const b = document.createElement("button"); b.className = `btn small ${cls || ""}`; b.textContent = text; b.onclick = fn; return b;
  }
  async function abort() {
    if (!(await ask("ABORT GAME?", { text: "The current run stops and its progress is lost.", ok: "ABORT", danger: true }))) return;
    try { await api("/api/cancel", { body: {} }); } catch (e) { toast(e.message, true); }
  }
  function update(job) {
    const n = job.stages.length;
    const overall = job.state === "done" ? 1 : (job.stage + job.progress) / n;
    const m = Math.floor(job.elapsed / 60), s = Math.floor(job.elapsed % 60);
    $("#game-time").textContent = `${m}:${String(s).padStart(2, "0")}`;
    $("#game-bar").style.width = (overall * 100).toFixed(1) + "%";
    $("#game-pct").textContent = Math.floor(overall * 100) + "%";
    $("#game-live").textContent = job.live || "";
    $("#game-log").textContent = job.log.join("\n");
    if (job.state === "running") {
      $("#game-title").textContent = `LEVEL ${job.stage + 1}/${n}: ${LABELS[job.stages[job.stage]]}`;
      $("#game-status").textContent = `${Math.floor(job.progress * 100)}% OF THIS LEVEL`;
      if (job.stage !== lastStage && lastStage >= 0) addScore(250);
      lastStage = job.stage;
      board.set(job.stage, job.progress);
      return;
    }
    clearInterval(poll);
    if (job.state === "done") {
      board.finish();
      addScore(1000);
      sfx("home");
      $("#game-title").textContent = "HOME! STAGE CLEAR";
      $("#game-status").textContent = job.output;
      $("#game-status").className = "file";
      if (job.extras && job.extras.length) $("#game-status").textContent += `\n+ ${job.extras.length} subtitle and transcript files next to it`;
      say("HOME! YOUR VIDEO IS READY. +1000 POINTS.");
      $("#game-actions").replaceChildren(
        button("SHOW FILE", "", () => api("/api/reveal", { body: { path: job.output } }).catch((e) => toast(e.message, true))),
        button("PLAY RESULT", "", () => { game.close(); setInput(job.output).then(() => video.play().catch(() => {})); }),
        button("NEW GAME", "", () => game.close()));
    } else {
      board.fail();
      sfx("error");
      $("#game-title").textContent = job.state === "cancelled" ? "GAME ABORTED" : "SPLAT! GAME OVER";
      $("#game-status").textContent = job.error || "Cancelled";
      say(job.state === "cancelled" ? "GAME ABORTED. READY WHEN YOU ARE." : "SPLAT! OPEN THE LOG TO SEE WHAT WENT WRONG.");
      $(".log", game).open = job.state === "error";
      $("#game-actions").replaceChildren(button("CONTINUE", "", () => game.close()));
    }
  }

  // ------------------------------------------------------------ exit
  $("#quit-btn").addEventListener("click", async () => {
    if (!(await ask("EXIT LEVYTSYA?", { text: "Any running game will be aborted.", ok: "EXIT", danger: true }))) return;
    try { await api("/api/cancel", { body: {} }); await api("/api/quit", { body: {} }); } catch (e) { /* already gone */ }
    block("GAME OVER", "Levytsya has stopped. You can close this tab.\nStart it again with Levytsya.command (Mac), Levytsya.bat (Windows) or python3 run.py.");
  });

  // ------------------------------------------------------------ boot
  // inside the desktop app (Electron): make room for the macOS window buttons
  if (window.levytsyaDesktop) document.body.classList.add("desktop", `desktop-${window.levytsyaDesktop.platform}`);

  (async function boot() {
    syncLevels();
    renderTrim();
    renderWm();
    await checkHealth();
    loadTemplateList();
    const running = await api("/api/job").catch(() => null);
    if (running && running.state === "running") { startGame(); openGame(running); }
    const last = store.get("lastInput", null);
    if (last) await setInput(last, true);
    validate();
  })();
})();
