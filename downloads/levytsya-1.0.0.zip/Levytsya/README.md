# Levytsya (левиця)

A retro video arcade for talk recordings. It stabilizes shaky footage, trims it, cleans room-recorded audio, adds a watermark, and makes transcripts and subtitles in several languages. Everything runs on your own computer.

There are three ways to use it:

- **The desktop app** (like жаба): installers for Apple Silicon Macs, Intel Macs and Windows. Its setup screen installs what it needs. See "Desktop app" below.
- **The web app**: double-click `Levytsya.command` (Mac) or `Levytsya.bat` (Windows), or run `python3 run.py`. The first run installs what it needs, then the app opens in your browser. See section 0.
- **The scripts**: each level is also a command-line script, documented in sections 3 to 8.

| Level | Script | What it does |
|---|---|---|
| 1 | `stabilize.py` | Smooths shaky handheld footage (section 3) |
| 2 | `trim.py` | Trims the start and end, removes chunks, using timestamps from the original video (section 6) |
| 3 | `clean_audio.py` | Removes noise, tames echo, evens out and boosts a room-recorded voice (section 5) |
| 4 | `watermark.py` | Adds a PNG logo and/or text, with reusable templates (section 7) |
| 5 | `subtitles.py` | Transcribes, translates and embeds subtitles in several languages (section 8) |

## Files

| File | Purpose |
|---|---|
| `Levytsya.command`, `Levytsya.bat`, `run.py` | Start the app (Mac, Windows, any system) |
| `app/` | The app: a small local server (`server.py`) and its retro web interface (`static/`) |
| `stabilize.py`, `trim.py`, `clean_audio.py`, `watermark.py`, `subtitles.py` | The five levels, usable on their own |
| `models/` | RNNoise speech model, downloaded automatically on first run |
| `requirements.txt` | Python dependencies for the app and scripts |
| `requirements-subtitles.txt` | Optional engine for subtitles (Whisper + offline translation) |
| `desktop/` | The desktop app (Electron): `main.js`, `preload.js`, icons, build settings in `package.json` |
| `app/static/setup.html`, `setup.js` | The desktop app's setup screen (ENGINE ROOM) |
| `site/` | The website, ready to upload to any static host |
| `tools/package.py` | Builds the download zip and copies the installers into `site/downloads/` |
| `tools/make_icon.py` | Generates the app icons from the lioness sprite |

## Desktop app

The desktop app wraps the same interface and engine in a native window, built with Electron and electron-builder exactly like жаба.

**Run in development**

```bash
cd desktop
npm install
npm start
```

**Build the installers**

```bash
cd desktop
npm run dist:mac     # dmg + zip for Apple Silicon and Intel
npm run dist:win     # NSIS installer + portable exe (builds fine from a Mac)
npm run dist         # all of them
cd .. && python3 tools/package.py   # copy them into site/downloads/
```

Output lands in `desktop/dist/`: `levytsya-1.0.0-mac-arm64.dmg`, `-mac-x64.dmg`, `-win-x64.exe` (installer) and `-win-portable.exe`. Change the version in `desktop/package.json` and `VERSION` in `app/server.py` together.

**How it runs**

1. The window opens on the setup screen (`app/static/setup.html`). It checks for Python 3.10 to 3.14 (3.12 preferred) and ffmpeg, and shows the install command for the platform if one is missing. macOS GUI apps don't see the Terminal's PATH, so the app also looks in Homebrew, python.org and WinGet locations.
2. INSTALL COMPONENTS creates a private virtual environment in the app's data folder (`~/Library/Application Support/Levytsya/venv` on Mac, `%APPDATA%\Levytsya\venv` on Windows) and installs `requirements.txt`. It reinstalls automatically when that file changes.
3. The app starts `app/server.py` on a free port and loads it in the window. EXIT, or closing the window, stops the server and any running job, ffmpeg included.

The scripts, the interface and the RNNoise model are bundled in the app's `Resources/engine` folder. Templates and temporary files still go to `~/.levytsya`, shared with the web version.

**Signing**: like жаба, the Mac app is ad-hoc signed by `desktop/build/adhoc-sign.js` after packaging. Don't remove it: without it, Apple Silicon Macs call a downloaded copy "damaged". Users still see a one-time block and click Open Anyway in System Settings → Privacy & Security. Removing that step needs a Developer ID certificate and notarization (a paid Apple Developer account). On Windows, users click "More info" then "Run anyway" on SmartScreen until the installer is signed.

**Screenshots**: `LEVYTSYA_SHOTS=/some/folder npm start` saves a capture of each page as it loads.

## 0. The web app

Requirements: Python 3.9+ and ffmpeg (see section 1). Then:

```bash
./Levytsya.command      # macOS: or double-click it in Finder
Levytsya.bat            # Windows: or double-click it
python3 run.py          # any system
```

The first run creates `.venv` and installs OpenCV, NumPy and Pillow. Later runs start straight away. The app opens at `http://127.0.0.1:8765`. Keep the terminal window open while you use it, and stop it with the EXIT button or Ctrl+C.

- Choose a video with CHOOSE VIDEO. The file browser shows your disks.
- Turn levels on or off with their switches. They always run in the order stabilize → trim → clean audio → watermark → subtitles.
- **Trim**: scrub the player, then press SET START, SET END, CUT FROM and CUT TO. All times refer to the original video.
- **Clean audio**: TEST 30 SEC renders a before/after sample from the player position.
- **Watermark**: PREVIEW renders the current frame with the watermark. Templates are saved in `~/.levytsya/templates` and also work with `watermark.py --template`.
- **Subtitles**: press INSTALL ENGINE once (see section 8).
- Press START. The lioness crosses one lane per level. The result is saved where OUTPUT says, next to the input by default.

The server only listens on your computer (127.0.0.1) and rejects requests that don't carry the page's secret token. Temporary files go to `~/.levytsya` and are deleted after each run.

**Publishing the website**: run `python3 tools/package.py`. It builds `site/downloads/levytsya-<version>.zip` and syncs the shared assets. Then upload the whole `site/` folder to GitHub Pages, Netlify or any web server.

## 1. Prerequisites

- **Python 3.9+**: check with `python3 --version` (macOS/Linux) or `python --version` (Windows).
- **ffmpeg** (optional, recommended): restores the audio track and encodes high-quality H.264.
  Without it, the output has no sound and uses a basic codec.
  - macOS: `brew install ffmpeg`
  - Windows: `winget install ffmpeg`
  - Ubuntu/Debian: `sudo apt install ffmpeg`

  Check with `ffmpeg -version`.

## 2. Create the virtual environment and install requirements

Open a terminal in the folder that contains `stabilize.py`.

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

**Windows (PowerShell)**

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

> If PowerShell blocks the activation script, run this once, then activate again:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

When the venv is active, your prompt starts with `(.venv)`.

## 3. Run it

```bash
python stabilize.py input.mov output.mp4
```

Example with options:

```bash
python stabilize.py IMG_1234.MOV IMG_1234_stable.mp4 --radius 50 --crop 0.06
```

| Option | Default | Effect |
|---|---|---|
| `--radius` | `30` | Smoothing window in frames. ~15 removes jitter but keeps intentional pans; 60–90 gives a gimbal-like glide. |
| `--crop` | `0.04` | Zoom (4%) that hides the black borders created by the correction. Increase to 0.06–0.10 for walking shots. |

Progress is printed for both passes (analysis, then writing). A 1-minute 4K clip takes a few minutes on a laptop.

## 4. Next time

The venv only needs to be created once. In later sessions:

```bash
source .venv/bin/activate        # macOS / Linux
.venv\Scripts\Activate.ps1       # Windows
python stabilize.py input.mov output.mp4
```

Leave the venv with `deactivate`.

## 5. Clean the audio of a talk

`clean_audio.py` is for a speaker recorded from the room: background noise, some echo, a weak or uneven signal. It only needs ffmpeg (no venv required), and works on audio files or videos. For a video, the picture is copied untouched and only the audio is replaced.

```bash
python clean_audio.py talk.mp4 talk_clean.mp4     # video in, video out
python clean_audio.py talk.mov talk_clean.wav     # audio only
```

Try settings on one minute first. This takes a few seconds:

```bash
python clean_audio.py talk.mp4 test.wav --start 300 --duration 60
```

| Option | Default | Effect |
|---|---|---|
| `--strength` | `1.0` | Denoiser strength, 0–1. Lower it (0.6–0.8) if the voice sounds metallic or "underwater". |
| `--target` | `-16` | Final loudness in LUFS. -16 suits YouTube and podcasts; -14 is louder. |
| `--stereo` | off | Keep the original channels. By default the output is mono, which suits a single speaker. |
| `--no-rnnoise` | off | Use ffmpeg's FFT denoiser instead of the neural one. |
| `--start`, `--duration` | whole file | Process only part of the file, in seconds. |

What it does, in order: downmix to mono, cut rumble below 80 Hz and hiss above 12 kHz, remove noise with the RNNoise neural model (trained on speech with recording noise), cut 250 Hz room boom, boost 3 kHz for clarity, even out the level when the speaker moves away from the mic, compress gently, and normalize loudness in two passes.

**Limit:** ffmpeg can't truly remove echo. The chain makes it less noticeable, but a very reverberant hall will still sound like a hall. For heavy echo, a dedicated tool such as DeepFilterNet or Adobe Podcast Enhance does better.

To stabilize and clean the same video, run `stabilize.py` first, then `clean_audio.py` on its output. If you also trim, see the recommended order in section 6.

## 6. Trim the video

`trim.py` cuts the beginning and end and removes any number of chunks in between, in one pass. It only needs ffmpeg.

**Give every timestamp as it appears in the original video**, the file you scrub through to note your cuts. The script works out which pieces to keep from those times, so removing one chunk never shifts the others. You don't have to recalculate anything.

```bash
python trim.py talk.mp4 talk_trimmed.mp4 --start 1:05 --end 1:02:30 \
    --cut 10:00-12:30 --cut 30:15-31:02.5
```

For a long list of cuts, put them in a text file, one per line, in any order:

```text
# cuts.txt
10:00 - 12:30      # projector failure
30:15 - 31:02.5
45:00 - 46:10      # Q&A off-mic
```

```bash
python trim.py talk.mp4 talk_trimmed.mp4 --start 1:05 --end 1:02:30 --cuts-file cuts.txt
```

| Option | Default | Effect |
|---|---|---|
| `--start` | beginning | Keep from this timestamp. |
| `--end` | end of video | Keep until this timestamp. |
| `--cut A-B` | none | Remove A to B. Repeat for each chunk. Overlapping cuts are merged. |
| `--cuts-file` | none | Text file of cuts, one `A-B` per line. `#` starts a comment. |
| `--dry-run` | off | Print the plan without encoding. |

Timestamps can be `SS`, `MM:SS` or `HH:MM:SS`, with decimals if needed (`1:02:30.5`).

Before encoding, the script prints each kept segment with its original time and its time in the new video. Use `--dry-run` to check the plan first. Cuts are frame-accurate because the video is re-encoded to H.264, and a 10 ms audio fade at each join prevents clicks.

**Recommended order for a talk:** `stabilize.py`, then `trim.py`, then `clean_audio.py`, then `watermark.py`, then `subtitles.py` (the app always uses this order). Stabilize before trimming because the motion tracking would be confused by the jumps at each join. Stabilizing doesn't change timestamps, so you can note your cuts on either the original or the stabilized file. Clean the audio last, so loudness is measured only on what you keep.

## 7. Add a watermark

`watermark.py` adds a PNG logo, a text, or both. Each has its own size, rotation, position and opacity. It uses Pillow, so activate the venv first (step 2 installs it).

```bash
python watermark.py talk.mp4 talk_wm.mp4 --logo logo.png --text "Datawise Academy"
```

**Check placement on one frame before encoding the whole video:**

```bash
python watermark.py talk.mp4 --preview frame.png --at 60 --logo logo.png --text "Datawise Academy"
```

**Templates.** Save your settings once, then reuse them on every video. Options you add on the command line override the template for that run only.

```bash
# save (no video needed)
python watermark.py --logo logo.png --logo-position top-right --logo-size 0.12 \
    --text "Datawise Academy\nCaribbean Session" --text-size 0.04 --save-template brand.json

# load
python watermark.py talk.mp4 talk_wm.mp4 --template brand.json

# load and change one thing
python watermark.py talk.mp4 talk_wm.mp4 --template brand.json --text "Guest lecture"
```

A template is a readable JSON file, so you can also edit it by hand. The logo path is stored as a full path.

| Option (logo / text) | Default | Effect |
|---|---|---|
| `--logo` / `--text` | none | PNG file (transparency is kept) / text. In text, `\n` starts a new line. |
| `--logo-size` | `0.15` | Logo width as a fraction of the video width. |
| `--text-size` | `0.05` | Font height as a fraction of the video height. |
| `--logo-angle`, `--text-angle` | `0` | Rotation in degrees, counter-clockwise. Use a negative number for clockwise. |
| `--logo-position`, `--text-position` | `bottom-right` / `bottom-left` | `top-left`, `top`, `top-right`, `left`, `center`, `right`, `bottom-left`, `bottom`, `bottom-right`, or `X,Y` from 0 to 1 (`0,0` top-left corner, `1,1` bottom-right corner, `0.5,0.8` centered and low). |
| `--logo-margin`, `--text-margin` | `0.03` | Distance from the edges, as a fraction of the video height. |
| `--logo-opacity`, `--text-opacity` | `0.85` | 0 = invisible, 1 = solid. |
| `--text-font` | Helvetica Neue | Path to a `.ttf`, `.otf` or `.ttc` font file. |
| `--text-color` | `white` | Name or hex code, e.g. `#FFD700`. |
| `--text-outline` | `0.08` | Outline width as a fraction of the font size. `0` removes it. |
| `--text-outline-color` | `black` | Outline color. |

Because sizes and positions are fractions of the video, one template looks the same on 720p, 1080p and 4K, and on portrait or landscape footage. iPhone portrait videos are detected correctly. On portrait videos, check long text with `--preview`, since the frame is narrow.

Example: a large diagonal "DRAFT" in the middle:

```bash
python watermark.py talk.mp4 draft.mp4 --text DRAFT --text-size 0.2 --text-angle 30 \
    --text-position center --text-opacity 0.3 --text-outline 0
```

The watermark re-encodes the video, so add it as the **last step**, after stabilizing, trimming and cleaning the audio. The audio is copied untouched when it's already AAC.

## 8. Transcripts and subtitles

`subtitles.py` transcribes the talk and writes subtitles in the spoken language, plus as many translations as you want. It needs an extra engine, installed once:

```bash
pip install -r requirements-subtitles.txt     # or press INSTALL ENGINE in the app
```

This installs Whisper (MLX on Apple Silicon, faster-whisper on Windows, Linux and Intel Macs, the same engines as жаба) and CTranslate2 for translation, about 500 MB. The first run also downloads the models once (about 2 GB). After that, everything works offline.

```bash
python subtitles.py talk.mp4 talk_subs.mp4 --languages fr,es,uk
python subtitles.py talk.mp4 transcripts/talk --source en --languages fr   # files only
python subtitles.py --list-languages
```

For every language it writes `NAME.<lang>.srt`, `NAME.<lang>.vtt` and a readable `NAME.<lang>.txt` transcript with timestamps. When the output is a video, all languages are also embedded as subtitle tracks that viewers can switch on in VLC, QuickTime, YouTube uploads and so on. The video and audio are copied untouched.

| Option | Default | Effect |
|---|---|---|
| `--languages` | none | Extra languages to translate into, comma-separated codes (`fr,es,uk,ht`…). |
| `--source` | `auto` | Language spoken in the video. Auto-detect works well. Force it if the talk mixes languages. |
| `--model` | `fast` | `fast` = Whisper large-v3 turbo. `best` = large-v3, a little more accurate and several times slower. |
| `--translator` | `m2m100` | `m2m100` (MIT license, free for any use) or `nllb` (NLLB-200: better translations, **non-commercial use only**). |

Supported translation languages: English, French, Spanish, German, Italian, Portuguese, Dutch, Ukrainian, Russian, Polish, Czech, Romanian, Hungarian, Greek, Swedish, Turkish, Arabic, Hebrew, Persian, Hindi, Chinese, Japanese, Korean, Vietnamese, Indonesian, Thai, Haitian Creole, Swahili.

How it works: Whisper's word timings are grouped into subtitles of at most 2 lines × 42 characters and 6 seconds, ending at a sentence when possible. Whole sentences are translated, so the translation keeps its context, then spread back over the subtitles they came from.

Accuracy follows the audio: run `clean_audio.py` first (the app does this automatically when both levels are on). Machine translations are good for understanding a talk; have a native speaker review them before an official release.

## Tips and troubleshooting

- **Getting the video off the iPhone**: AirDrop it to a Mac, or use Photos › Export. Choosing "Most Compatible" (H.264) in the export options avoids HEVC/HDR issues.
- **Washed-out colors**: the clip was recorded in HDR (the iPhone default). OpenCV reads 8-bit SDR, which flattens HDR colors. Export as "Most Compatible", or turn off HDR for future recordings in Settings › Camera › Formats.
- **Black or wavy edges remain**: increase `--crop`.
- **Intentional camera moves feel sluggish**: lower `--radius`.
- **`ModuleNotFoundError: No module named 'cv2'`**: the venv isn't active. Activate it and run again.
- **`ffmpeg not found` message**: install ffmpeg (step 1) to get audio and better quality.
- **Limits**: stabilization can't remove motion blur already in the frames, and only partly fixes rolling-shutter "jello" from fast shakes.
