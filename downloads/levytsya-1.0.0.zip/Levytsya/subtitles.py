#!/usr/bin/env python3
"""
subtitles.py: transcribe a talk and make subtitles in several languages.

  1. Whisper large-v3 turbo transcribes the speech (language auto-detected).
     MLX on Apple Silicon, faster-whisper elsewhere: the same engines as жаба.
  2. Word timings are grouped into readable subtitle cues (max 2 lines of 42
     characters, max 6 seconds, preferably ending at a sentence).
  3. Each sentence is translated offline with M2M-100 (default, MIT license) or
     NLLB-200 (better quality, non-commercial license), then spread back over
     the cues it came from so timing stays in sync.
  4. For every language it writes NAME.<lang>.srt, NAME.<lang>.vtt and a
     readable NAME.<lang>.txt transcript. If the output is a video, all the
     languages are also embedded as subtitle tracks viewers can switch on.

Everything runs locally; models are downloaded once from Hugging Face.

Usage:
    python subtitles.py talk.mp4 talk_subtitled.mp4 --languages fr,es,uk
    python subtitles.py talk.mp4 talk_subtitled.mp4 --source en --languages fr
    python subtitles.py talk.mp4 transcripts/talk           # files only, no video
    python subtitles.py talk.mp4 out.mp4 --languages de --translator nllb --model best

    --languages   extra languages to translate into (comma-separated codes)
    --source      language spoken in the video (default: auto-detect)
    --model       fast (large-v3 turbo, default) or best (large-v3, slower)
    --translator  m2m100 (default, MIT) or nllb (better, non-commercial use only)
    --list-languages  show the supported language codes

Requires: pip install -r requirements-subtitles.txt; ffmpeg and ffprobe on PATH.
"""
import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# code: (name, NLLB code, ISO 639-2 tag for the video's subtitle track)
# M2M-100 and Whisper use the two-letter code itself.
LANGS = {
    "en": ("English", "eng_Latn", "eng"), "fr": ("French", "fra_Latn", "fra"),
    "es": ("Spanish", "spa_Latn", "spa"), "de": ("German", "deu_Latn", "deu"),
    "it": ("Italian", "ita_Latn", "ita"), "pt": ("Portuguese", "por_Latn", "por"),
    "nl": ("Dutch", "nld_Latn", "nld"), "uk": ("Ukrainian", "ukr_Cyrl", "ukr"),
    "ru": ("Russian", "rus_Cyrl", "rus"), "pl": ("Polish", "pol_Latn", "pol"),
    "cs": ("Czech", "ces_Latn", "ces"), "ro": ("Romanian", "ron_Latn", "ron"),
    "hu": ("Hungarian", "hun_Latn", "hun"), "el": ("Greek", "ell_Grek", "ell"),
    "sv": ("Swedish", "swe_Latn", "swe"), "tr": ("Turkish", "tur_Latn", "tur"),
    "ar": ("Arabic", "arb_Arab", "ara"), "he": ("Hebrew", "heb_Hebr", "heb"),
    "fa": ("Persian", "pes_Arab", "fas"), "hi": ("Hindi", "hin_Deva", "hin"),
    "zh": ("Chinese", "zho_Hans", "zho"), "ja": ("Japanese", "jpn_Jpan", "jpn"),
    "ko": ("Korean", "kor_Hang", "kor"), "vi": ("Vietnamese", "vie_Latn", "vie"),
    "id": ("Indonesian", "ind_Latn", "ind"), "th": ("Thai", "tha_Thai", "tha"),
    "ht": ("Haitian Creole", "hat_Latn", "hat"), "sw": ("Swahili", "swh_Latn", "swa"),
}
NO_SPACES = {"zh", "ja", "th"}  # scripts written without spaces between words
WHISPER = {
    "mlx": {"fast": "mlx-community/whisper-large-v3-turbo",
            "best": "mlx-community/whisper-large-v3-mlx"},
    "faster": {"fast": "large-v3-turbo", "best": "large-v3"},
}
TRANSLATORS = {
    "m2m100": "jncraton/m2m100_418M-ct2-int8",              # MIT
    "nllb": "JustFrederik/nllb-200-distilled-600M-ct2-int8",  # CC-BY-NC 4.0
}
VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".mkv"}
MAX_LINE, MAX_CHARS, MAX_DUR = 42, 84, 6.0
SENTENCE_END = re.compile(r"[.!?…。！？]['\"”»)]?$")


def fmt_clock(t, sep=","):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


def progress(fraction, label):
    print(f"PROGRESS {fraction * 100:5.1f}% {label}", flush=True)


# ---------------------------------------------------------------- transcription

def extract_audio(src, wav):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-map", "0:a:0",
                    "-vn", "-ac", "1", "-ar", "16000", wav], check=True)
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "csv=p=0", wav], capture_output=True, text=True).stdout
    return float(out.strip() or 0)


def use_mlx():
    return sys.platform == "darwin" and platform.machine() == "arm64"


def transcribe(wav, duration, model, language):
    """Return (language, [ {word, start, end} ... ]) whatever engine runs."""
    words = []
    if use_mlx():
        import mlx_whisper
        mt = sys.modules.get("mlx_whisper.transcribe")  # the package's transcribe() hides the module

        class Bar:  # mlx_whisper reports progress through tqdm; print it our way
            def __init__(self, total=0, **_):
                self.total, self.n = total or 1, 0
            def update(self, n):
                self.n += n
                progress(0.05 + 0.65 * min(self.n / self.total, 1), "transcribing")
            def __enter__(self):
                return self
            def __exit__(self, *exc):
                return False
        if mt is not None and hasattr(mt, "tqdm"):
            mt.tqdm = type("tqdm_shim", (), {"tqdm": Bar})
        print(f"Transcribing with MLX Whisper ({WHISPER['mlx'][model]})...", flush=True)
        result = mlx_whisper.transcribe(wav, path_or_hf_repo=WHISPER["mlx"][model],
                                        language=language, word_timestamps=True,
                                        condition_on_previous_text=False, verbose=False)
        for seg in result.get("segments", []):
            words += seg.get("words") or [{"word": seg["text"], "start": seg["start"],
                                           "end": seg["end"]}]
        return result.get("language") or language, words

    from faster_whisper import WhisperModel
    print(f"Transcribing with faster-whisper ({WHISPER['faster'][model]})...", flush=True)
    fw = WhisperModel(WHISPER["faster"][model], device="auto", compute_type="auto")
    segments, info = fw.transcribe(wav, language=language, word_timestamps=True,
                                   vad_filter=True, condition_on_previous_text=False)
    for seg in segments:
        words += ([{"word": w.word, "start": w.start, "end": w.end} for w in seg.words]
                  if seg.words else [{"word": seg.text, "start": seg.start, "end": seg.end}])
        progress(0.05 + 0.65 * min(seg.end / max(duration, 1), 1), "transcribing")
    return info.language or language, words


# ---------------------------------------------------------------- cues

def join_words(ws):
    # Whisper words carry their own leading space ("decision", "-making"), so
    # joining them as-is is right for every script, spaced or not
    return re.sub(r"\s+", " ", "".join(w["word"] for w in ws)).strip()


def build_cues(words, lang):
    cues, cur = [], []

    def flush():
        if cur:
            cues.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                         "text": join_words(cur)})
            cur.clear()

    for w in words:
        if not w["word"].strip():
            continue
        if cur:
            candidate = join_words(cur + [w])
            if (len(candidate) > MAX_CHARS or w["end"] - cur[0]["start"] > MAX_DUR
                    or w["start"] - cur[-1]["end"] > 1.2):
                flush()
        cur.append(w)
        text = join_words(cur)
        if SENTENCE_END.search(text) and (len(text) > 20 or cur[-1]["end"] - cur[0]["start"] > 1.5):
            flush()
    flush()
    # readable timing: at least ~0.8 s on screen, never overlapping the next cue
    for i, c in enumerate(cues):
        nxt = cues[i + 1]["start"] if i + 1 < len(cues) else c["end"] + 2
        c["end"] = min(max(c["end"] + 0.2, c["start"] + 0.8), nxt - 0.04)
        c["end"] = max(c["end"], c["start"] + 0.3)
    return [c for c in cues if c["text"]]


def wrap(text, lang):
    """Two balanced lines when the text is long."""
    if len(text) <= MAX_LINE:
        return text
    if lang in NO_SPACES or " " not in text:
        mid = len(text) // 2
        return text[:mid] + "\n" + text[mid:]
    mid = len(text) / 2
    spaces = [i for i, ch in enumerate(text) if ch == " "]
    cut = min(spaces, key=lambda i: abs(i - mid))
    return text[:cut] + "\n" + text[cut + 1:]


# ---------------------------------------------------------------- translation

class Translator:
    def __init__(self, kind):
        import ctranslate2
        import sentencepiece
        from huggingface_hub import snapshot_download

        self.kind = kind
        print(f"Loading translator {TRANSLATORS[kind]} (downloaded once)...", flush=True)
        path = Path(snapshot_download(TRANSLATORS[kind]))
        self.model = ctranslate2.Translator(str(path), device="cpu", compute_type="int8",
                                            intra_threads=max(os.cpu_count() or 4, 1))
        self.sp = sentencepiece.SentencePieceProcessor(model_file=str(path / "sentencepiece.bpe.model"))

    def token(self, lang):
        return LANGS[lang][1] if self.kind == "nllb" else f"__{lang}__"

    def translate(self, texts, src, tgt):
        source = [[self.token(src)] + self.sp.encode(t, out_type=str) + ["</s>"] for t in texts]
        results = self.model.translate_batch(source, target_prefix=[[self.token(tgt)]] * len(texts),
                                             beam_size=4, max_batch_size=16,
                                             max_decoding_length=256)
        return [self.sp.decode(r.hypotheses[0][1:]).strip() for r in results]


def sentence_groups(cues):
    """Consecutive cues that form a sentence (max 4), translated together."""
    groups, cur = [], []
    for i, c in enumerate(cues):
        cur.append(i)
        if SENTENCE_END.search(c["text"]) or len(cur) == 4:
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    return groups


def spread(translation, cues, idxs, lang):
    """Split one translated sentence back over its cues, by source length."""
    if len(idxs) == 1:
        return [translation]
    units = list(translation) if lang in NO_SPACES else translation.split()
    glue = "" if lang in NO_SPACES else " "
    weights = [max(len(cues[i]["text"]), 1) for i in idxs]
    total, out, pos = sum(weights), [], 0
    for k, w in enumerate(weights):
        take = len(units) - pos if k == len(weights) - 1 else round(len(units) * w / total)
        out.append(glue.join(units[pos:pos + take]))
        pos += take
    return [o or "…" for o in out]


def translate_cues(cues, src, targets, kind):
    tr = Translator(kind)
    groups = sentence_groups(cues)
    sentences = [" ".join(cues[i]["text"] for i in g) for g in groups]
    out = {}
    for n, tgt in enumerate(targets):
        texts = [""] * len(cues)
        done = 0
        for start in range(0, len(groups), 32):
            batch = groups[start:start + 32]
            translated = tr.translate(sentences[start:start + 32], src, tgt)
            for g, t in zip(batch, translated):
                for i, piece in zip(g, spread(t, cues, g, tgt)):
                    texts[i] = piece
            done += len(batch)
            progress(0.72 + 0.23 * (n + done / len(groups)) / len(targets),
                     f"translating {LANGS[tgt][0]}")
        out[tgt] = [dict(c, text=texts[i]) for i, c in enumerate(cues)]
        print(f"  {LANGS[tgt][0]}: {len(cues)} subtitles", flush=True)
    return out


# ---------------------------------------------------------------- output

def write_srt(cues, lang, path):
    with open(path, "w", encoding="utf-8") as fh:
        for i, c in enumerate(cues, 1):
            fh.write(f"{i}\n{fmt_clock(c['start'])} --> {fmt_clock(c['end'])}\n"
                     f"{wrap(c['text'], lang)}\n\n")


def write_vtt(cues, lang, path):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("WEBVTT\n\n")
        for c in cues:
            fh.write(f"{fmt_clock(c['start'], '.')} --> {fmt_clock(c['end'], '.')}\n"
                     f"{wrap(c['text'], lang)}\n\n")


def write_txt(cues, lang, path, title, note):
    glue = "" if lang in NO_SPACES else " "
    paragraphs, cur, sentences = [], [], 0
    for i, c in enumerate(cues):
        gap = c["start"] - cues[i - 1]["end"] if i else 0
        if cur and (gap > 2.5 or sentences >= 5):
            paragraphs.append(cur)
            cur, sentences = [], 0
        cur.append(c)
        sentences += bool(SENTENCE_END.search(c["text"]))
    if cur:
        paragraphs.append(cur)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"# {title}\n# {note}\n\n")
        for p in paragraphs:
            m, s = divmod(int(p[0]["start"]), 60)
            h, m = divmod(m, 60)
            stamp = f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
            fh.write(f"[{stamp}] " + glue.join(c["text"] for c in p) + "\n\n")


def embed(src, dst, tracks):
    """Copy video and audio, add one subtitle track per language."""
    ext = Path(dst).suffix.lower()
    codec = "srt" if ext == ".mkv" else "mov_text"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", src]
    for path, _ in tracks:
        cmd += ["-i", path]
    cmd += ["-map", "0:v:0", "-map", "0:a:0?"]
    for i in range(len(tracks)):
        cmd += ["-map", f"{i + 1}:0"]
    cmd += ["-c:v", "copy", "-c:a", "copy", "-c:s", codec]
    for i, (_, lang) in enumerate(tracks):
        cmd += [f"-metadata:s:s:{i}", f"language={LANGS[lang][2]}",
                f"-metadata:s:s:{i}", f"title={LANGS[lang][0]}"]
    if ext in (".mp4", ".m4v", ".mov"):
        cmd += ["-movflags", "+faststart"]
    subprocess.run(cmd + [dst], check=True)


def main():
    ap = argparse.ArgumentParser(description="Transcribe a talk and make multilingual subtitles.")
    ap.add_argument("input", nargs="?")
    ap.add_argument("output", nargs="?",
                    help="video file (subtitles embedded) or a base name for the files only")
    ap.add_argument("--languages", default="",
                    help="extra languages to translate into, e.g. fr,es,uk")
    ap.add_argument("--source", default="auto", help="spoken language (default auto)")
    ap.add_argument("--model", choices=["fast", "best"], default="fast")
    ap.add_argument("--translator", choices=list(TRANSLATORS), default="m2m100")
    ap.add_argument("--list-languages", action="store_true")
    args = ap.parse_args()

    if args.list_languages:
        for code, (name, *_rest) in LANGS.items():
            print(f"  {code}  {name}")
        return
    if not (args.input and args.output):
        ap.error("give INPUT and OUTPUT")
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        sys.exit("ffmpeg and ffprobe must be on PATH")
    targets = [c.strip().lower() for c in args.languages.split(",") if c.strip()]
    unknown = [c for c in targets + ([args.source] if args.source != "auto" else [])
               if c not in LANGS]
    if unknown:
        sys.exit(f"Unknown language code(s): {', '.join(unknown)} (see --list-languages)")

    out = Path(args.output)
    as_video = out.suffix.lower() in VIDEO_EXTS
    base = out.with_suffix("") if as_video or out.suffix.lower() in (".srt", ".vtt", ".txt") else out
    base.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "speech.wav")
        print("Extracting audio...", flush=True)
        duration = extract_audio(args.input, wav)
        progress(0.05, "transcribing")
        lang, words = transcribe(wav, duration, args.model,
                                 None if args.source == "auto" else args.source)
        if lang not in LANGS:
            print(f"  Detected language '{lang}' has no translation support: "
                  "subtitles are written in that language only.", flush=True)
        cues = build_cues(words, lang)
        if not cues:
            sys.exit("No speech found in the audio")
        name = LANGS.get(lang, (lang,))[0]
        print(f"  Detected language: {name} · {len(cues)} subtitles", flush=True)
        progress(0.7, "transcribed")

        by_lang = {lang: cues}
        targets = [t for t in dict.fromkeys(targets) if t != lang]
        if targets and lang in LANGS:
            by_lang.update(translate_cues(cues, lang, targets, args.translator))
        elif targets:
            print("  Skipping translation (unsupported source language).", flush=True)

        progress(0.96, "writing files")
        tracks = []
        for code, cs in by_lang.items():
            lname = LANGS.get(code, (code,))[0]
            note = ("Original language" if code == lang
                    else f"Machine translation from {name} ({args.translator})")
            write_srt(cs, code, f"{base}.{code}.srt")
            write_vtt(cs, code, f"{base}.{code}.vtt")
            write_txt(cs, code, f"{base}.{code}.txt", f"Transcript · {lname}", note)
            print(f"  wrote {base.name}.{code}.srt / .vtt / .txt", flush=True)
            if code in LANGS:
                tracks.append((f"{base}.{code}.srt", code))
        if as_video:
            print("Embedding subtitle tracks...", flush=True)
            embed(args.input, str(out), tracks)
    progress(1.0, "done")
    print(f"Done -> {args.output}")


if __name__ == "__main__":
    main()
