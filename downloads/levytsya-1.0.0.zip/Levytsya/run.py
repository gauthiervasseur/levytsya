#!/usr/bin/env python3
"""
run.py: start Levytsya.

On the first run it creates a private Python environment (.venv) next to this
file and installs the requirements; later runs start straight away. Then it
launches the local server and opens the app in your browser.

    python3 run.py              # macOS / Linux
    py run.py                   # Windows
    python3 run.py --port 9000  # any server option is passed through
"""
import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
REQS = ROOT / "requirements.txt"
STAMP = VENV / ".levytsya-requirements"


def venv_python():
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def main():
    if sys.version_info < (3, 9):
        sys.exit("Levytsya needs Python 3.9 or newer: https://www.python.org/downloads/")
    print("\n  LEVYTSYA · левиця\n")
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        print("  ! ffmpeg was not found. The app will open, but can't process videos until\n"
              "    you install it:  macOS: brew install ffmpeg   Windows: winget install ffmpeg\n"
              "    Linux: sudo apt install ffmpeg\n")

    if not venv_python().exists():
        print("  First run: creating the Python environment (one time only)...")
        subprocess.run([sys.executable, "-m", "venv", str(VENV)], check=True)
    want = hashlib.sha256(REQS.read_bytes()).hexdigest()
    if not STAMP.exists() or STAMP.read_text().strip() != want:
        print("  Installing OpenCV, NumPy and Pillow (a minute or two)...")
        py = str(venv_python())
        subprocess.run([py, "-m", "pip", "install", "--quiet", "--upgrade", "pip"], check=True)
        subprocess.run([py, "-m", "pip", "install", "--quiet", "-r", str(REQS)], check=True)
        STAMP.write_text(want)

    try:
        subprocess.run([str(venv_python()), str(ROOT / "app" / "server.py"), *sys.argv[1:]])
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
