#!/usr/bin/env python3
"""
clean_audio.py: clean up a conference talk recorded from the room
(background noise, room echo, low or uneven level). Works on audio files and
on videos (the video stream is copied untouched, only the audio is replaced).

Chain (all ffmpeg filters, no Python packages needed):
  1. Downmix to mono (a single speaker doesn't need stereo).
  2. High-pass 80 Hz / low-pass 12 kHz: drop HVAC rumble, handling noise, hiss.
  3. RNNoise neural denoiser trained on speech with recording noise
     (model downloaded once into ./models). Falls back to an FFT denoiser
     with --no-rnnoise.
  4. EQ: cut 250 Hz "boxiness" (room boom / echo build-up), boost 3 kHz
     presence for intelligibility.
  5. Dynamic normalizer: evens out the level when the speaker moves or turns
     away from the mic, lifts a weak signal by up to +26 dB.
  6. Gentle compressor, then two-pass EBU R128 loudness normalization
     (-16 LUFS by default, the usual target for online video/podcasts).

Note on echo: true de-reverberation isn't possible with ffmpeg alone. Steps 3-4
reduce how much it is noticed, but a very reverberant room will still sound
like a room.

Usage:
    python clean_audio.py talk.mov talk_clean.mp4       # video in, video out
    python clean_audio.py talk.mov talk_clean.wav       # extract clean audio
    python clean_audio.py talk.mov test.wav --start 300 --duration 60   # preview
    python clean_audio.py talk.mov out.mp4 --strength 0.7 --target -14

    --strength  denoiser strength 0..1 (lower if the voice sounds "underwater")
    --target    loudness in LUFS (default -16)
    --stereo    keep the original channels instead of downmixing to mono

Requires: ffmpeg and ffprobe on PATH.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request

MODEL_URL = ("https://raw.githubusercontent.com/GregorR/rnnoise-models/master/"
             "somnolent-hogwash-2018-09-01/sh.rnnn")
MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
MODEL_FILE = "sh.rnnn"
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".m4v"}
LOSSY_EXTS = {".mp4", ".mov", ".mkv", ".m4v", ".m4a", ".mp3", ".aac"}


def ensure_model():
    path = os.path.join(MODEL_DIR, MODEL_FILE)
    if not os.path.exists(path):
        print(f"Downloading RNNoise speech model to {path} ...")
        os.makedirs(MODEL_DIR, exist_ok=True)
        urllib.request.urlretrieve(MODEL_URL, path + ".part")
        os.replace(path + ".part", path)
    return path


def has_video(ffprobe, path):
    out = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v",
                          "-show_entries", "stream=codec_type", "-of", "csv=p=0",
                          path], capture_output=True, text=True).stdout
    return "video" in out


def build_chain(args):
    f = []
    if not args.stereo:
        f.append("aformat=channel_layouts=mono")
    f += ["highpass=f=80", "lowpass=f=12000"]
    if args.no_rnnoise:
        f.append(f"afftdn=nr={12 * args.strength:.1f}:nf=-30:tn=1")
    else:
        # ffmpeg runs with cwd=MODEL_DIR so the path needs no filter escaping
        f.append(f"arnndn=m={MODEL_FILE}:mix={args.strength}")
    f += ["equalizer=f=250:t=q:w=1:g=-3",
          "equalizer=f=3000:t=q:w=1.5:g=3",
          "dynaudnorm=f=250:g=15:p=0.9:m=20",
          "acompressor=threshold=-20dB:ratio=2.5:attack=10:release=150"]
    return ",".join(f)


def main():
    ap = argparse.ArgumentParser(description="Clean speech recorded in a room.")
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--strength", type=float, default=1.0,
                    help="denoiser strength 0..1 (default 1.0)")
    ap.add_argument("--target", type=float, default=-16.0,
                    help="integrated loudness in LUFS (default -16)")
    ap.add_argument("--stereo", action="store_true",
                    help="keep original channels instead of downmixing to mono")
    ap.add_argument("--no-rnnoise", action="store_true",
                    help="use ffmpeg's FFT denoiser instead of RNNoise")
    ap.add_argument("--start", type=float, help="start at this many seconds")
    ap.add_argument("--duration", type=float, help="process only this many seconds")
    args = ap.parse_args()

    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not (ffmpeg and ffprobe):
        sys.exit("ffmpeg and ffprobe must be on PATH")
    src, dst = os.path.abspath(args.input), os.path.abspath(args.output)
    if not os.path.exists(src):
        sys.exit(f"Cannot find {src}")
    os.makedirs(MODEL_DIR, exist_ok=True)
    if not args.no_rnnoise:
        ensure_model()

    trim = []
    if args.start is not None:
        trim += ["-ss", str(args.start)]
    if args.duration is not None:
        trim += ["-t", str(args.duration)]
    chain = build_chain(args)
    loud = f"loudnorm=I={args.target}:TP=-1.5:LRA=11"

    print("Pass 1/2: cleaning and measuring loudness...")
    p = subprocess.run([ffmpeg, "-hide_banner", "-nostats", *trim, "-i", src,
                        "-map", "0:a:0", "-af", f"{chain},{loud}:print_format=json",
                        "-f", "null", "-"],
                       cwd=MODEL_DIR, capture_output=True, text=True)
    blocks = re.findall(r"\{[^{}]*\}", p.stderr)
    if p.returncode != 0 or not blocks:
        sys.exit(f"ffmpeg failed during analysis:\n{p.stderr[-2000:]}")
    m = json.loads(blocks[-1])
    print(f"  input loudness {m['input_i']} LUFS, true peak {m['input_tp']} dBTP")
    loud += (f":measured_I={m['input_i']}:measured_TP={m['input_tp']}"
             f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}"
             f":offset={m['target_offset']}:linear=true")

    keep_video = has_video(ffprobe, src) and os.path.splitext(dst)[1].lower() in VIDEO_EXTS
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-stats",
           *trim, "-i", src]
    if keep_video:
        cmd += ["-map", "0:v:0", "-c:v", "copy"]
    else:
        cmd += ["-vn"]
    cmd += ["-map", "0:a:0", "-af", f"{chain},{loud},aresample=48000"]
    if os.path.splitext(dst)[1].lower() in LOSSY_EXTS:
        cmd += ["-c:a", "aac" if not dst.lower().endswith(".mp3") else "libmp3lame",
                "-b:a", "192k"]
    if dst.lower().endswith((".mp4", ".m4v", ".mov", ".m4a")):
        cmd += ["-movflags", "+faststart"]
    cmd.append(dst)

    print("Pass 2/2: writing " + ("video with cleaned audio" if keep_video
                                  else "cleaned audio") + "...")
    subprocess.run(cmd, cwd=MODEL_DIR, check=True)
    print(f"Done -> {args.output}")


if __name__ == "__main__":
    main()
