#!/usr/bin/env python3
"""
stabilize.py: stabilize shaky video (e.g. iPhone footage) with OpenCV.

Method (two passes, so long 4K clips don't have to fit in RAM):
  1. Track corner features frame-to-frame (Lucas-Kanade optical flow) and
     estimate the inter-frame motion (dx, dy, rotation) with RANSAC.
  2. Accumulate it into a camera trajectory, smooth it with a moving average,
     and warp each frame by the difference (smoothed - raw).
  3. Zoom slightly to hide the black borders created by the warp.
  4. If ffmpeg is installed, re-encode to H.264 and copy the original audio back.

Usage:
    python stabilize.py input.mov output.mp4
    python stabilize.py input.mov output.mp4 --radius 50 --crop 0.06

    --radius  smoothing window in frames (higher = smoother, more "gimbal-like")
    --crop    zoom factor to hide borders (0.04 = 4%)

Requires: pip install opencv-python numpy
Optional: ffmpeg on PATH (for audio and good-quality H.264 output)
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile

import cv2
import numpy as np


def estimate_transforms(path, analysis_width=960, max_corners=300):
    """Pass 1: per-frame motion (dx, dy, angle) in full-resolution pixels."""
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        sys.exit(f"Cannot open {path}")
    ok, prev = cap.read()
    if not ok:
        sys.exit("Cannot read the first frame")

    # Analyse a downscaled copy: much faster on 4K, barely less accurate.
    scale = min(1.0, analysis_width / prev.shape[1])

    def prep(frame):
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if scale < 1.0:
            g = cv2.resize(g, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        return g

    prev_gray = prep(prev)
    transforms = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        gray = prep(frame)
        dx = dy = da = 0.0
        pts = cv2.goodFeaturesToTrack(prev_gray, maxCorners=max_corners,
                                      qualityLevel=0.01, minDistance=20, blockSize=3)
        if pts is not None and len(pts) >= 10:
            nxt, status, _ = cv2.calcOpticalFlowPyrLK(prev_gray, gray, pts, None)
            good = status.ravel() == 1
            if good.sum() >= 10:
                m, _ = cv2.estimateAffinePartial2D(pts[good], nxt[good],
                                                   method=cv2.RANSAC,
                                                   ransacReprojThreshold=3.0)
                if m is not None:
                    dx, dy = m[0, 2] / scale, m[1, 2] / scale
                    da = np.arctan2(m[1, 0], m[0, 0])
        transforms.append((dx, dy, da))
        prev_gray = gray
        if len(transforms) % 100 == 0:
            print(f"  analysed {len(transforms)} frames", end="\r")
    cap.release()
    print()
    return np.array(transforms, dtype=np.float64).reshape(-1, 3)


def smooth(trajectory, radius):
    """Centered moving average on each column, edge-padded."""
    k = np.ones(2 * radius + 1) / (2 * radius + 1)
    out = np.empty_like(trajectory)
    for c in range(trajectory.shape[1]):
        padded = np.pad(trajectory[:, c], radius, mode="edge")
        out[:, c] = np.convolve(padded, k, mode="valid")
    return out


def to3x3(m):
    return np.vstack([m, [0.0, 0.0, 1.0]])


def write_stabilized(src, dst, corrections, crop):
    """Pass 2: re-read the video and warp each frame."""
    cap = cv2.VideoCapture(src)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    ok, frame = cap.read()
    if not ok:
        sys.exit("Cannot re-read the video")
    h, w = frame.shape[:2]  # taken from the frame, so iPhone rotation is respected
    writer = cv2.VideoWriter(dst, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))

    zoom = to3x3(cv2.getRotationMatrix2D((w / 2, h / 2), 0, 1.0 + crop))
    identity = np.float64([[1, 0, 0], [0, 1, 0]])

    i = 0
    while ok:
        if i >= len(corrections):
            m = identity
        else:
            dx, dy, da = corrections[i]
            c, s = np.cos(da), np.sin(da)
            m = np.float64([[c, -s, dx], [s, c, dy]])
        final = (zoom @ to3x3(m))[:2]
        writer.write(cv2.warpAffine(frame, final, (w, h),
                                    flags=cv2.INTER_LINEAR,
                                    borderMode=cv2.BORDER_REFLECT))
        ok, frame = cap.read()
        i += 1
        if i % 100 == 0:
            print(f"  wrote {i} frames", end="\r")
    print()
    cap.release()
    writer.release()


def main():
    ap = argparse.ArgumentParser(description="Stabilize a shaky video.")
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--radius", type=int, default=30,
                    help="smoothing radius in frames (default 30)")
    ap.add_argument("--crop", type=float, default=0.04,
                    help="zoom to hide borders, e.g. 0.04 = 4%% (default)")
    args = ap.parse_args()

    print("Pass 1/2: estimating camera motion...")
    transforms = estimate_transforms(args.input)
    # trajectory[k] = accumulated camera motion at frame k (frame 0 = origin)
    trajectory = np.vstack([np.zeros((1, 3)), np.cumsum(transforms, axis=0)])
    smoothed = smooth(trajectory, args.radius)
    corrections = smoothed - trajectory  # move frame k from raw path onto smooth path

    ffmpeg = shutil.which("ffmpeg")
    tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False).name
    print("Pass 2/2: warping frames...")
    write_stabilized(args.input, tmp if ffmpeg else args.output, corrections, args.crop)

    if ffmpeg:
        print("Encoding H.264 and restoring audio with ffmpeg...")
        subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-stats",
                        "-i", tmp, "-i", args.input,
                        "-map", "0:v", "-map", "1:a:0?",
                        "-c:v", "libx264", "-crf", "18", "-preset", "medium",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest",
                        args.output], check=True)
        os.remove(tmp)
    else:
        print("ffmpeg not found: output has no audio and uses the basic mp4v codec.")
    print(f"Done -> {args.output}")


if __name__ == "__main__":
    main()
