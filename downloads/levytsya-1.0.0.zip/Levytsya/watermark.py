#!/usr/bin/env python3
"""
watermark.py: add a PNG logo and/or a text watermark to a video, with size,
rotation, opacity and position for each. Settings can be saved to and loaded
from a JSON template, so the same branding is reused on every video.

Sizes, margins and positions are relative to the video, so one template looks
the same on 720p, 1080p and 4K footage, and on portrait or landscape videos.

  size      logo: fraction of the video width (0.15 = 15% of the width)
            text: font height as a fraction of the video height (0.05 = 5%)
  angle     rotation in degrees, counter-clockwise (e.g. 30, -45, 90)
  position  top-left, top, top-right, left, center, right, bottom-left,
            bottom, bottom-right, or "X,Y" from 0 to 1 (0,0 = top-left corner,
            1,1 = bottom-right corner, 0.5,0.5 = centered)
  margin    distance from the edges, as a fraction of the video height
  opacity   0 (invisible) to 1 (solid)

Usage:
    python watermark.py talk.mp4 out.mp4 --logo logo.png --text "Datawise Academy"
    python watermark.py talk.mp4 out.mp4 --logo logo.png --logo-position top-right \\
        --logo-size 0.12 --text "© 2026" --text-position bottom-left --text-size 0.035

    # check placement on a single frame before encoding the whole video
    python watermark.py talk.mp4 --preview frame.png --at 60 --template brand.json

    # templates: save once, reuse everywhere (command-line options override them)
    python watermark.py --logo logo.png --text "Datawise" --save-template brand.json
    python watermark.py talk.mp4 out.mp4 --template brand.json
    python watermark.py talk.mp4 out.mp4 --template brand.json --text "Guest talk"

Requires: pip install pillow; ffmpeg and ffprobe on PATH.
"""
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile

from PIL import Image, ImageColor, ImageDraw, ImageFont

POSITIONS = {
    "top-left": (0, 0), "top": (0.5, 0), "top-right": (1, 0),
    "left": (0, 0.5), "center": (0.5, 0.5), "right": (1, 0.5),
    "bottom-left": (0, 1), "bottom": (0.5, 1), "bottom-right": (1, 1),
}
DEFAULT_FONTS = ["/System/Library/Fonts/HelveticaNeue.ttc",       # macOS
                 "/System/Library/Fonts/Helvetica.ttc",
                 "C:/Windows/Fonts/arial.ttf",                    # Windows
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]  # Linux
DEFAULTS = {
    "logo": {"path": None, "size": 0.15, "angle": 0, "position": "bottom-right",
             "margin": 0.03, "opacity": 0.85},
    "text": {"content": None, "size": 0.05, "angle": 0, "position": "bottom-left",
             "margin": 0.03, "opacity": 0.85, "font": None, "color": "#FFFFFF",
             "outline": 0.08, "outline_color": "#000000"},
}
# command-line option -> (template section, key)
OPTION_MAP = {
    "logo": ("logo", "path"), "logo_size": ("logo", "size"),
    "logo_angle": ("logo", "angle"), "logo_position": ("logo", "position"),
    "logo_margin": ("logo", "margin"), "logo_opacity": ("logo", "opacity"),
    "text": ("text", "content"), "text_size": ("text", "size"),
    "text_angle": ("text", "angle"), "text_position": ("text", "position"),
    "text_margin": ("text", "margin"), "text_opacity": ("text", "opacity"),
    "text_font": ("text", "font"), "text_color": ("text", "color"),
    "text_outline": ("text", "outline"), "text_outline_color": ("text", "outline_color"),
}


def load_settings(args):
    settings = json.loads(json.dumps(DEFAULTS))  # deep copy
    if args.template:
        with open(args.template) as fh:
            saved = json.load(fh)
        for section in settings:
            settings[section].update(saved.get(section) or {})
    for option, (section, key) in OPTION_MAP.items():
        value = getattr(args, option)
        if value is not None:
            settings[section][key] = value
    if settings["logo"]["path"]:
        settings["logo"]["path"] = os.path.abspath(settings["logo"]["path"])
    if settings["text"]["content"]:
        settings["text"]["content"] = settings["text"]["content"].replace("\\n", "\n")
    return settings


def parse_position(value):
    if value in POSITIONS:
        return POSITIONS[value]
    try:
        fx, fy = (float(v) for v in value.split(","))
    except ValueError:
        sys.exit(f"Bad position '{value}': use one of {', '.join(POSITIONS)} or X,Y")
    return fx, fy


def video_size(ffprobe, path):
    """Displayed width/height (iPhone portrait videos are stored rotated)."""
    out = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v:0",
                          "-show_entries", "stream=width,height:stream_side_data=rotation",
                          "-of", "json", path], capture_output=True, text=True).stdout
    streams = json.loads(out or "{}").get("streams")
    if not streams:
        sys.exit(f"No video stream in {path}")
    s = streams[0]
    w, h = s["width"], s["height"]
    rotation = next((d.get("rotation", 0) for d in s.get("side_data_list", [])), 0)
    return (h, w) if abs(int(rotation)) % 180 == 90 else (w, h)


def finish(img, opacity, angle):
    alpha = img.getchannel("A").point(lambda a: round(a * opacity))
    img.putalpha(alpha)
    if angle:
        img = img.rotate(angle, resample=Image.BICUBIC, expand=True)
    return img


def render_logo(cfg, W):
    img = Image.open(cfg["path"]).convert("RGBA")
    width = max(1, round(W * cfg["size"]))
    img = img.resize((width, max(1, round(img.height * width / img.width))),
                     Image.LANCZOS)
    return finish(img, cfg["opacity"], cfg["angle"])


def load_font(name, size):
    candidates = [name] if name else DEFAULT_FONTS
    for font in candidates:
        try:
            return ImageFont.truetype(font, size)
        except OSError:
            continue
    if name:
        sys.exit(f"Cannot load font '{name}' (give the path to a .ttf/.otf/.ttc file)")
    return ImageFont.load_default(size)


def render_text(cfg, H):
    size = max(1, round(H * cfg["size"]))
    font = load_font(cfg["font"], size)
    text = cfg["content"]
    stroke = round(size * cfg["outline"])
    probe = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    left, top, right, bottom = probe.multiline_textbbox(
        (0, 0), text, font=font, stroke_width=stroke, align="center")
    left, top, right, bottom = (math.floor(left), math.floor(top),
                                math.ceil(right), math.ceil(bottom))
    img = Image.new("RGBA", (right - left + 2, bottom - top + 2), (0, 0, 0, 0))
    ImageDraw.Draw(img).multiline_text(
        (1 - left, 1 - top), text, font=font, align="center",
        fill=ImageColor.getrgb(cfg["color"]), stroke_width=stroke,
        stroke_fill=ImageColor.getrgb(cfg["outline_color"]))
    return finish(img, cfg["opacity"], cfg["angle"])


def place(img, cfg, W, H):
    fx, fy = parse_position(cfg["position"])
    m = round(H * cfg["margin"])
    return (round(m + fx * (W - img.width - 2 * m)),
            round(m + fy * (H - img.height - 2 * m)))


def audio_codec(ffprobe, path):
    return subprocess.run([ffprobe, "-v", "error", "-select_streams", "a:0",
                           "-show_entries", "stream=codec_name", "-of", "csv=p=0",
                           path], capture_output=True, text=True).stdout.strip()


def main():
    ap = argparse.ArgumentParser(description="Add a logo and/or text watermark to a video.")
    ap.add_argument("input", nargs="?")
    ap.add_argument("output", nargs="?")
    ap.add_argument("--template", help="load settings from this JSON file")
    ap.add_argument("--save-template", metavar="FILE",
                    help="save the resulting settings to this JSON file")
    ap.add_argument("--preview", metavar="PNG", help="render one frame instead of the video")
    ap.add_argument("--at", type=float, default=5.0,
                    help="time in seconds of the preview frame (default 5)")
    g = ap.add_argument_group("logo")
    g.add_argument("--logo", metavar="PNG", help="logo image (PNG with transparency)")
    g.add_argument("--logo-size", type=float, help="fraction of video width (default 0.15)")
    g.add_argument("--logo-angle", type=float, help="degrees counter-clockwise (default 0)")
    g.add_argument("--logo-position", help="named position or X,Y (default bottom-right)")
    g.add_argument("--logo-margin", type=float, help="fraction of video height (default 0.03)")
    g.add_argument("--logo-opacity", type=float, help="0..1 (default 0.85)")
    g = ap.add_argument_group("text")
    g.add_argument("--text", help='text to show; "\\n" starts a new line')
    g.add_argument("--text-size", type=float, help="fraction of video height (default 0.05)")
    g.add_argument("--text-angle", type=float, help="degrees counter-clockwise (default 0)")
    g.add_argument("--text-position", help="named position or X,Y (default bottom-left)")
    g.add_argument("--text-margin", type=float, help="fraction of video height (default 0.03)")
    g.add_argument("--text-opacity", type=float, help="0..1 (default 0.85)")
    g.add_argument("--text-font", help="path to a .ttf/.otf/.ttc font (default Helvetica Neue)")
    g.add_argument("--text-color", help="e.g. white, #FFD700 (default white)")
    g.add_argument("--text-outline", type=float,
                   help="outline width as a fraction of font size, 0 = none (default 0.08)")
    g.add_argument("--text-outline-color", help="default black")
    args = ap.parse_args()

    settings = load_settings(args)
    if args.save_template:
        with open(args.save_template, "w") as fh:
            json.dump(settings, fh, indent=2)
        print(f"Template saved -> {args.save_template}")
        if not args.input:
            return

    if not args.input or not (args.output or args.preview):
        ap.error("give INPUT and OUTPUT (or INPUT with --preview)")
    logo, text = settings["logo"], settings["text"]
    if not (logo["path"] or text["content"]):
        ap.error("nothing to add: give --logo and/or --text (or a --template)")
    if logo["path"] and not os.path.exists(logo["path"]):
        sys.exit(f"Cannot find logo {logo['path']}")
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not (ffmpeg and ffprobe):
        sys.exit("ffmpeg and ffprobe must be on PATH")

    W, H = video_size(ffprobe, args.input)
    tmpdir = tempfile.mkdtemp()
    layers = []
    if logo["path"]:
        layers.append((render_logo(logo, W), logo))
    if text["content"]:
        layers.append((render_text(text, H), text))

    inputs, chain, prev = [], [], "[0:v]"
    for i, (img, cfg) in enumerate(layers, 1):
        png = os.path.join(tmpdir, f"layer{i}.png")
        img.save(png)
        x, y = place(img, cfg, W, H)
        inputs += ["-i", png]
        chain.append(f"{prev}[{i}:v]overlay={x}:{y}[v{i}]")
        prev = f"[v{i}]"
    chain[-1] = chain[-1].rsplit("[", 1)[0] + ",format=yuv420p[vout]"
    graph = ";".join(chain)

    try:
        if args.preview:
            subprocess.run([ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                            "-ss", str(args.at), "-i", args.input, *inputs,
                            "-filter_complex", graph, "-map", "[vout]",
                            "-frames:v", "1", args.preview], check=True)
            print(f"Preview ({W}x{H}, t={args.at}s) -> {args.preview}")
            return
        acodec = audio_codec(ffprobe, args.input)
        print(f"Adding watermark to {W}x{H} video...")
        cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-stats",
               "-i", args.input, *inputs, "-filter_complex", graph,
               "-map", "[vout]", "-c:v", "libx264", "-crf", "18", "-preset", "medium"]
        if acodec:
            cmd += ["-map", "0:a:0", "-c:a", "copy" if acodec == "aac" else "aac"]
        cmd += ["-movflags", "+faststart", args.output]
        subprocess.run(cmd, check=True)
        print(f"Done -> {args.output}")
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
