/* Levytsya desktop setup screen: checks Python, ffmpeg and the components,
   installs what's missing, then asks the main process to start the engine. */
(function () {
  "use strict";
  const D = window.levytsyaDesktop;
  const $ = (s) => document.querySelector(s);
  Levytsya.mountLioness($("#sprite"), 6);

  const HELP = {
    darwin: {
      python: { text: "Install Python 3.12 from python.org (the macOS installer), or with Homebrew:",
                cmd: "brew install python@3.12", link: ["PYTHON.ORG", "https://www.python.org/downloads/macos/"] },
      ffmpeg: { text: "Install it with Homebrew in the Terminal app (no Homebrew yet? get it at brew.sh first):",
                cmd: "brew install ffmpeg", link: ["BREW.SH", "https://brew.sh"] },
    },
    win32: {
      python: { text: "Download Python 3.12 from python.org. In the installer, tick \"Add python.exe to PATH\". Or in PowerShell:",
                cmd: "winget install Python.Python.3.12", link: ["PYTHON.ORG", "https://www.python.org/downloads/windows/"] },
      ffmpeg: { text: "Install it in PowerShell, then press RE-CHECK:",
                cmd: "winget install ffmpeg", link: ["FFMPEG.ORG", "https://ffmpeg.org/download.html"] },
    },
    linux: {
      python: { text: "Install Python 3.10 or newer with your package manager:", cmd: "sudo apt install python3 python3-venv" },
      ffmpeg: { text: "Install ffmpeg with your package manager:", cmd: "sudo apt install ffmpeg" },
    },
  };
  const help = HELP[D.platform] || HELP.linux;

  let state = null;
  let installing = false;

  function setRow(id, ok, detail, helpInfo) {
    const row = $(id);
    const pill = row.querySelector(".pill");
    pill.className = `pill ${ok ? "ok" : "bad"}`;
    pill.textContent = ok ? "READY" : "MISSING";
    row.querySelector(".detail").textContent = detail || "";
    const block = row.querySelector(".help-block");
    if (!block) return;
    block.replaceChildren();
    if (ok || !helpInfo) return;
    const p = document.createElement("p");
    p.textContent = helpInfo.text;
    block.append(p);
    const line = document.createElement("div");
    line.className = "cmd";
    const code = document.createElement("code");
    code.textContent = helpInfo.cmd;
    const copy = document.createElement("button");
    copy.className = "btn tiny";
    copy.textContent = "COPY";
    copy.onclick = () => navigator.clipboard.writeText(helpInfo.cmd).then(() => { copy.textContent = "COPIED"; });
    line.append(code, copy);
    if (helpInfo.link) {
      const a = document.createElement("button");
      a.className = "btn tiny go";
      a.textContent = helpInfo.link[0];
      a.onclick = () => D.openExternal(helpInfo.link[1]);
      line.append(a);
    }
    block.append(line);
  }

  function say(text, blink) {
    $("#status-line").textContent = text;
    $("#status-line").classList.toggle("blink", !!blink);
  }

  function log(line) {
    const c = $("#console");
    $("#console-box").hidden = false;
    c.textContent += line + "\n";
    c.scrollTop = c.scrollHeight;
  }

  async function check(autostart) {
    say("CHECKING…", true);
    state = await D.status();
    $("#checks").hidden = false;
    const py = state.python;
    setRow("#row-python", !!py, py ? `Python ${py.version} · ${py.exe}` : "", help.python);
    const ff = !!(state.ffmpeg && state.ffprobe);
    setRow("#row-ffmpeg", ff, ff ? state.ffmpeg : "", help.ffmpeg);
    setRow("#row-components", state.components, state.components ? state.venvDir : "", null);
    $("#foot").textContent = `Private folder: ${state.venvDir}`;

    const ready = !!py && ff && state.components;
    $("#install-btn").hidden = !py || state.components || installing;
    $("#recheck-btn").hidden = ready;
    $("#start-btn").hidden = !ready;
    if (ready) {
      say("ALL SYSTEMS GO!");
      if (autostart) start();
    } else if (!py || !ff) {
      say("INSTALL WHAT'S MISSING, THEN PRESS RE-CHECK");
    } else {
      say("ONE LAST STEP: INSTALL THE COMPONENTS");
    }
  }

  async function install(fresh) {
    installing = true;
    $("#install-btn").hidden = true;
    $("#reinstall-btn").hidden = true;
    $("#recheck-btn").hidden = true;
    say("INSTALLING… GRAB A COFFEE", true);
    const r = await D.install({ fresh });
    if (!r.ok) {
      installing = false;
      log(`! ${r.error}`);
      say("INSTALL COULD NOT START");
      check(false);
    }
  }

  function start() {
    say("STARTING THE ENGINE…", true);
    $("#start-btn").hidden = true;
    D.start();
  }

  D.onInstallLog(log);
  D.onInstallDone((r) => {
    installing = false;
    if (r.ok) {
      log("### COMPONENTS INSTALLED");
      check(true);
    } else {
      log(`! ${r.error}`);
      say("SPLAT! THE INSTALL FAILED");
      $("#reinstall-btn").hidden = false;
      $("#recheck-btn").hidden = false;
    }
  });
  D.onServerFailed((r) => {
    log(`! The engine stopped before it was ready (exit code ${r.code}).`);
    (r.log || []).forEach(log);
    say("SPLAT! THE ENGINE DIDN'T START");
    $("#reinstall-btn").hidden = false;
    $("#recheck-btn").hidden = false;
  });

  $("#install-btn").onclick = () => install(false);
  $("#reinstall-btn").onclick = () => install(true);
  $("#recheck-btn").onclick = () => check(false);
  $("#start-btn").onclick = start;

  check(true);
})();
