#!/usr/bin/env python3
"""
Levytsya local server: serves the retro web interface and runs the four video
scripts (stabilize, trim, clean_audio, watermark) as a pipeline.

Standard library only. Listens on 127.0.0.1, and every API call must carry the
random token embedded in the page, so other websites open in the browser can't
drive it.

Usage (normally started by run.py):
    python app/server.py [--port 8765] [--no-browser]
"""
import argparse
import importlib.util
import json
import mimetypes
import os
import platform
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

VERSION = "1.0.0"
APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
STATIC = APP_DIR / "static"
DATA = Path.home() / ".levytsya"
TEMPLATES = DATA / "templates"
WORK = DATA / "work"
PREVIEWS = DATA / "previews"
TOKEN = secrets.token_urlsafe(24)

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"}
AUDIO_EXT = {".wav", ".mp3", ".m4a", ".aac", ".flac"}
IMAGE_EXT = {".png", ".jpg", ".jpeg"}
FONT_EXT = {".ttf", ".otf", ".ttc"}
KINDS = {"video": VIDEO_EXT, "audio": AUDIO_EXT, "image": IMAGE_EXT, "font": FONT_EXT}
TOOLS = {"stabilize": "stabilize.py", "trim": "trim.py", "clean": "clean_audio.py",
         "watermark": "watermark.py", "subtitles": "subtitles.py"}
ORDER = list(TOOLS)

TIME_RE = re.compile(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)")
FRAMES_RE = re.compile(r"(analysed|wrote) (\d+) frames")
RESULT_RE = re.compile(r"Result: (\d+):(\d+):(\d+(?:\.\d+)?)")
PROGRESS_RE = re.compile(r"^PROGRESS\s+([\d.]+)%\s*(.*)")
NAME_RE = re.compile(r"^[\w .-]{1,40}$")

allowed_hosts = set()
job_lock = threading.Lock()
current_job = None
engine_job = None  # pip install of the optional subtitles engine


# ---------------------------------------------------------------- helpers

def kind_of(path):
    ext = Path(path).suffix.lower()
    return next((k for k, exts in KINDS.items() if ext in exts), None)


def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                          "format=duration:stream=codec_type,codec_name,width,height,"
                          "avg_frame_rate,nb_frames:stream_side_data=rotation",
                          "-of", "json", path], capture_output=True, text=True)
    if out.returncode != 0:
        raise ValueError(f"Cannot read {path}")
    data = json.loads(out.stdout)
    duration = float(data.get("format", {}).get("duration") or 0)
    info = {"path": path, "duration": duration, "has_audio": False, "has_video": False,
            "width": 0, "height": 0, "fps": 0, "frames": 0, "vcodec": None}
    for s in data.get("streams", []):
        if s.get("codec_type") == "audio":
            info["has_audio"] = True
        elif s.get("codec_type") == "video" and not info["has_video"]:
            num, _, den = (s.get("avg_frame_rate") or "0/1").partition("/")
            fps = float(num) / float(den or 1) if float(den or 1) else 0
            w, h = s.get("width", 0), s.get("height", 0)
            rot = next((d.get("rotation", 0) for d in s.get("side_data_list", [])), 0)
            if abs(int(rot)) % 180 == 90:
                w, h = h, w
            info.update(has_video=True, width=w, height=h, fps=round(fps, 3),
                        vcodec=s.get("codec_name"),
                        frames=int(s.get("nb_frames") or duration * fps or 0))
    return info


def hms(seconds):
    h, rem = divmod(int(seconds), 3600)
    return f"{h}:{rem // 60:02d}:{rem % 60:02d}"


def to_seconds(h, m, s):
    return int(h) * 3600 + int(m) * 60 + float(s)


def tool_args(tool, opts, workdir):
    """Translate UI options into command-line arguments (no shell is involved)."""
    if tool == "stabilize":
        return ["--radius", str(int(opts.get("radius", 30))),
                "--crop", str(float(opts.get("crop", 0.04)))]
    if tool == "trim":
        args = []
        for key in ("start", "end"):
            if str(opts.get(key) or "").strip():
                args += [f"--{key}", str(opts[key]).strip()]
        for cut in opts.get("cuts") or []:
            args += ["--cut", str(cut).strip()]
        return args
    if tool == "clean":
        args = ["--strength", str(float(opts.get("strength", 1.0))),
                "--target", str(float(opts.get("target", -16)))]
        if opts.get("stereo"):
            args.append("--stereo")
        if opts.get("no_rnnoise"):
            args.append("--no-rnnoise")
        return args
    if tool == "subtitles":
        langs = [c for c in opts.get("languages") or [] if re.fullmatch(r"[a-z]{2}", str(c))]
        args = ["--model", "best" if opts.get("model") == "best" else "fast",
                "--translator", "nllb" if opts.get("translator") == "nllb" else "m2m100"]
        if re.fullmatch(r"[a-z]{2}", str(opts.get("source") or "")):
            args += ["--source", opts["source"]]
        if langs:
            args += ["--languages", ",".join(langs)]
        return args
    if tool == "watermark":
        tpl = Path(workdir) / "watermark.json"
        tpl.write_text(json.dumps(opts.get("settings") or {}, indent=2))
        return ["--template", str(tpl)]
    raise ValueError(f"Unknown tool {tool}")


class StageProgress:
    """Turn a script's console output into a 0..1 progress value."""

    def __init__(self, tool, ctx):
        self.tool, self.ctx, self.value, self.phase = tool, ctx, 0.0, 0

    def feed(self, line):
        t, ctx = self.tool, self.ctx
        if t == "trim" and (m := RESULT_RE.search(line)):
            new = to_seconds(*m.groups())
            if ctx["duration"]:
                ctx["frames"] = int(ctx["frames"] * new / ctx["duration"])
            ctx["duration"] = new
        if t == "stabilize":
            if m := FRAMES_RE.search(line):
                # pass 1 (analysed) = 0-40%, pass 2 (wrote) = 40-80%, encode = 80-100%
                frac = min(int(m.group(2)) / max(ctx["frames"], 1), 1.0)
                self.value = 0.4 * frac if m.group(1) == "analysed" else 0.4 + 0.4 * frac
            elif "Encoding" in line:
                self.phase, self.value = 1, 0.8
        elif t == "clean" and "Pass 2/2" in line:
            self.phase, self.value = 1, 0.35
        elif t == "subtitles" and (m := PROGRESS_RE.match(line)):
            self.value = float(m.group(1)) / 100
        if m := TIME_RE.search(line):
            frac = min(to_seconds(*m.groups()) / max(ctx["duration"], 0.001), 1.0)
            if t == "stabilize" and self.phase:
                self.value = 0.8 + 0.2 * frac
            elif t == "clean":
                self.value = 0.35 + 0.65 * frac if self.phase else self.value
            elif t in ("trim", "watermark"):
                self.value = frac
        self.value = min(max(self.value, 0.0), 1.0)
        return self.value


class Job:
    def __init__(self, src, dst, stages):
        self.id = uuid.uuid4().hex[:8]
        self.input, self.output, self.stages = src, dst, stages
        self.state, self.stage, self.progress = "running", 0, 0.0
        self.log, self.live = deque(maxlen=300), ""
        self.error, self.proc, self.cancelled = None, None, False
        self.extras = []
        self.started, self.finished = time.time(), None

    def snapshot(self):
        return {"id": self.id, "state": self.state, "input": self.input,
                "output": self.output, "stages": [s["tool"] for s in self.stages],
                "stage": self.stage, "progress": round(self.progress, 4),
                "log": list(self.log)[-60:], "live": self.live, "error": self.error,
                "extras": self.extras,
                "elapsed": round((self.finished or time.time()) - self.started, 1)}


def kill_tree(proc):
    """Stop a script and the ffmpeg it started (terminate() alone leaves ffmpeg running)."""
    if proc is None or proc.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
    else:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            proc.terminate()


# each job script gets its own process group so kill_tree() reaches its children
GROUP = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt"
         else {"start_new_session": True})


def run_job(job):
    work = WORK / job.id
    work.mkdir(parents=True, exist_ok=True)
    try:
        info = probe(job.input)
        ctx = {"duration": info["duration"], "frames": info["frames"]}
        src = job.input
        for i, stage in enumerate(job.stages):
            job.stage, job.progress = i, 0.0
            last = i == len(job.stages) - 1
            dst = job.output if last else str(work / f"step{i + 1}.mp4")
            tool = stage["tool"]
            cmd = [sys.executable, "-u", str(ROOT / TOOLS[tool]), src, dst,
                   *tool_args(tool, stage.get("options") or {}, work)]
            job.log.append(f"### LEVEL {i + 1}: {tool.upper()}")
            tracker = StageProgress(tool, ctx)
            job.proc = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT, bufsize=0, **GROUP)
            buf = b""
            while chunk := job.proc.stdout.read(4096):
                buf += chunk
                *lines, buf = re.split(rb"[\r\n]", buf)
                for raw in lines:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line:
                        continue
                    job.progress = tracker.feed(line)
                    if line.startswith(("frame=", "size=")) or FRAMES_RE.search(line):
                        job.live = line
                    elif m := PROGRESS_RE.match(line):
                        job.live = f"{m.group(2)} {float(m.group(1)):.0f}%"
                    else:
                        job.log.append(line)
            code = job.proc.wait()
            if job.cancelled:
                job.state = "cancelled"
                return
            if code != 0:
                job.state = "error"
                job.error = f"{tool} failed (exit code {code})"
                return
            job.progress = 1.0
            job.live = ""
            src = dst
        job.state = "done"
        base = Path(job.output).with_suffix("")
        job.extras = sorted(str(p) for p in base.parent.glob(f"{glob_escape(base.name)}.*.*")
                            if p.suffix in (".srt", ".vtt", ".txt"))
        job.log.append(f"### HOME! {job.output}")
        job.log.extend(f"    + {Path(p).name}" for p in job.extras)
    except Exception as exc:  # report anything unexpected to the UI
        job.state, job.error = "error", str(exc)
    finally:
        job.finished = time.time()
        shutil.rmtree(work, ignore_errors=True)


def glob_escape(name):
    return re.sub(r"([*?\[])", r"[\1]", name)


def subtitle_languages():
    """Read the language table from subtitles.py without importing its engine."""
    text = (ROOT / "subtitles.py").read_text(encoding="utf-8")
    return re.findall(r'"([a-z]{2})": \("([^"]+)", "[^"]+", "[a-z]{3}"\)', text)


def engine_ready():
    asr = (importlib.util.find_spec("mlx_whisper") if sys.platform == "darwin"
           and platform.machine() == "arm64" else importlib.util.find_spec("faster_whisper"))
    return bool(asr and importlib.util.find_spec("ctranslate2")
                and importlib.util.find_spec("sentencepiece"))


class EngineInstall:
    """pip install -r requirements-subtitles.txt in the background."""

    def __init__(self):
        self.state, self.log = "running", deque(maxlen=200)
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        cmd = [sys.executable, "-m", "pip", "install", "--progress-bar", "off",
               "-r", str(ROOT / "requirements-subtitles.txt")]
        try:
            proc = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True)
            for line in proc.stdout:
                if line.strip():
                    self.log.append(line.rstrip())
            ok = proc.wait() == 0
            importlib.invalidate_caches()
            self.state = "done" if ok and engine_ready() else "error"
        except OSError as exc:
            self.log.append(str(exc))
            self.state = "error"

    def snapshot(self):
        return {"state": self.state, "log": list(self.log)[-40:]}


def list_dir(path, kinds):
    p = Path(path).expanduser() if path else Path.home()
    p = p.resolve()
    if not p.is_dir():
        p = p.parent
    entries = []
    try:
        for child in sorted(p.iterdir(), key=lambda c: c.name.lower()):
            if child.name.startswith("."):
                continue
            try:
                is_dir = child.is_dir()
                st = child.stat()
            except OSError:
                continue
            k = None if is_dir else kind_of(child)
            if is_dir or (k and (not kinds or k in kinds)):
                entries.append({"name": child.name, "path": str(child), "dir": is_dir, "kind": k,
                                "size": 0 if is_dir else st.st_size, "mtime": st.st_mtime})
    except PermissionError:
        pass
    entries.sort(key=lambda e: not e["dir"])
    home = Path.home()
    places = [{"name": "Home", "path": str(home)}]
    places += [{"name": n, "path": str(home / n)} for n in ("Desktop", "Downloads", "Movies",
                                                           "Videos", "Documents")
               if (home / n).is_dir()]
    if Path("/Volumes").is_dir():
        places += [{"name": v.name, "path": str(v)} for v in Path("/Volumes").iterdir()
                   if not v.name.startswith(".")]
    if os.name == "nt":  # drive letters (C:, D:, USB keys, network drives)
        places += [{"name": f"{d}:", "path": f"{d}:\\"} for d in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                   if os.path.exists(f"{d}:\\")]
    return {"path": str(p), "parent": str(p.parent) if p.parent != p else None,
            "entries": entries, "places": places}


def clear_previews():
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    for f in PREVIEWS.iterdir():
        if time.time() - f.stat().st_mtime > 600:
            f.unlink(missing_ok=True)


def preview_watermark(body):
    clear_previews()
    tag = uuid.uuid4().hex[:8]
    tpl = PREVIEWS / f"wm-{tag}.json"
    tpl.write_text(json.dumps(body.get("settings") or {}))
    png = PREVIEWS / f"wm-{tag}.png"
    p = subprocess.run([sys.executable, str(ROOT / "watermark.py"), body["input"],
                        "--preview", str(png), "--at", str(float(body.get("at", 5))),
                        "--template", str(tpl)], cwd=ROOT, capture_output=True,
                       text=True, timeout=120)
    tpl.unlink(missing_ok=True)
    if p.returncode != 0:
        raise ValueError((p.stderr or p.stdout).strip()[-600:])
    return {"image": str(png)}


def preview_audio(body):
    clear_previews()
    tag = uuid.uuid4().hex[:8]
    start = max(float(body.get("start", 0)), 0)
    dur = min(max(float(body.get("duration", 30)), 1), 120)
    before, after = PREVIEWS / f"before-{tag}.wav", PREVIEWS / f"after-{tag}.wav"
    p = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(start), "-t",
                        str(dur), "-i", body["input"], "-map", "0:a:0", "-vn",
                        str(before)], capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        raise ValueError(p.stderr.strip()[-600:] or "No audio track")
    opts = body.get("options") or {}
    p = subprocess.run([sys.executable, str(ROOT / "clean_audio.py"), body["input"],
                        str(after), "--start", str(start), "--duration", str(dur),
                        *tool_args("clean", opts, PREVIEWS)], cwd=ROOT,
                       capture_output=True, text=True, timeout=300)
    if p.returncode != 0:
        raise ValueError((p.stderr or p.stdout).strip()[-600:])
    return {"before": str(before), "after": str(after)}


def reveal(path):
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path])
    elif os.name == "nt":
        subprocess.Popen(["explorer", "/select,", path])
    else:
        subprocess.Popen(["xdg-open", str(Path(path).parent)])


def health():
    return {"version": VERSION, "ffmpeg": bool(shutil.which("ffmpeg")),
            "ffprobe": bool(shutil.which("ffprobe")),
            "opencv": importlib.util.find_spec("cv2") is not None,
            "pillow": importlib.util.find_spec("PIL") is not None,
            "subtitles_engine": engine_ready(), "languages": subtitle_languages(),
            "templates_dir": str(TEMPLATES), "home": str(Path.home()),
            "busy": bool(current_job and current_job.state == "running")}


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    server_version = f"Levytsya/{VERSION}"

    def log_message(self, fmt, *args):  # keep the terminal quiet
        pass

    # -- plumbing
    def send_json(self, obj, status=200):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def fail(self, status, message):
        self.send_json({"error": message}, status)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def allowed(self, query, need_token=True):
        if self.headers.get("Host", "") not in allowed_hosts:
            self.fail(403, "bad host")
            return False
        token = self.headers.get("X-Levytsya-Token") or query.get("token", [""])[0]
        if need_token and not secrets.compare_digest(token, TOKEN):
            self.fail(403, "bad token")
            return False
        return True

    def send_file(self, path, ctype=None):
        size = os.path.getsize(path)
        ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
        start, end, status = 0, size - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if m and size:
            s, e = m.groups()
            if s:
                start, end = int(s), int(e) if e else size - 1
            elif e:
                start = max(size - int(e), 0)
            end, status = min(end, size - 1), 206
        if start > end and size:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{size}")
            self.end_headers()
            return
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1 if size else 0))
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as fh:
                fh.seek(start)
                left = end - start + 1
                while left > 0 and (chunk := fh.read(min(1 << 20, left))):
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # -- routes
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        url = urlparse(self.path)
        q = parse_qs(url.query)
        route = url.path
        if route in ("/", "/index.html"):
            if not self.allowed(q, need_token=False):
                return
            html = (STATIC / "index.html").read_text(encoding="utf-8")
            body = html.replace("{{TOKEN}}", TOKEN).replace("{{VERSION}}", VERSION).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if route.startswith("/static/"):
            if not self.allowed(q, need_token=False):
                return
            target = (STATIC / unquote(route[len("/static/"):])).resolve()
            if STATIC not in target.parents or not target.is_file():
                return self.fail(404, "not found")
            return self.send_file(str(target))
        if not route.startswith("/api/"):
            return self.fail(404, "not found")
        if not self.allowed(q):
            return
        try:
            if route == "/api/health":
                return self.send_json(health())
            if route == "/api/ls":
                kinds = [k for k in q.get("kinds", [""])[0].split(",") if k]
                return self.send_json(list_dir(q.get("path", [""])[0], kinds))
            if route == "/api/probe":
                return self.send_json(probe(q["path"][0]))
            if route == "/api/media":
                path = q["path"][0]
                if not kind_of(path) or not os.path.isfile(path):
                    return self.fail(404, "not a media file")
                ctype = "video/mp4" if Path(path).suffix.lower() in (".mov", ".m4v") else None
                return self.send_file(path, ctype)
            if route == "/api/job":
                return self.send_json(current_job.snapshot() if current_job else None)
            if route == "/api/engine":
                return self.send_json(engine_job.snapshot() if engine_job else
                                      {"state": "done" if engine_ready() else "missing", "log": []})
            if route == "/api/templates":
                TEMPLATES.mkdir(parents=True, exist_ok=True)
                return self.send_json(sorted(f.stem for f in TEMPLATES.glob("*.json")))
            if route.startswith("/api/templates/"):
                name = unquote(route.rsplit("/", 1)[1])
                f = TEMPLATES / f"{name}.json"
                if not NAME_RE.match(name) or not f.is_file():
                    return self.fail(404, "no such template")
                return self.send_json(json.loads(f.read_text()))
            return self.fail(404, "not found")
        except (KeyError, ValueError) as exc:
            return self.fail(400, str(exc))

    def do_POST(self):
        global current_job, engine_job
        url = urlparse(self.path)
        if not self.allowed(parse_qs(url.query)):
            return
        route = url.path
        try:
            body = self.body()
            if route == "/api/run":
                src, dst = body["input"], body["output"]
                stages = sorted((s for s in body.get("stages", []) if s.get("tool") in TOOLS),
                                key=lambda s: ORDER.index(s["tool"]))
                if not stages:
                    return self.fail(400, "Turn on at least one level")
                if not os.path.isfile(src):
                    return self.fail(400, f"Cannot find {src}")
                if Path(dst).suffix.lower() not in VIDEO_EXT:
                    return self.fail(400, "Output must be a video file (.mp4, .mov, .mkv)")
                if os.path.abspath(src) == os.path.abspath(dst):
                    return self.fail(400, "Output must be different from the input")
                Path(dst).parent.mkdir(parents=True, exist_ok=True)
                with job_lock:
                    if current_job and current_job.state == "running":
                        return self.fail(409, "A game is already running")
                    current_job = Job(src, dst, stages)
                threading.Thread(target=run_job, args=(current_job,), daemon=True).start()
                return self.send_json(current_job.snapshot())
            if route == "/api/engine/install":
                if not (engine_job and engine_job.state == "running"):
                    engine_job = EngineInstall()
                return self.send_json(engine_job.snapshot())
            if route == "/api/cancel":
                job = current_job
                if job and job.state == "running":
                    job.cancelled = True
                    kill_tree(job.proc)
                return self.send_json({"ok": True})
            if route == "/api/preview/watermark":
                return self.send_json(preview_watermark(body))
            if route == "/api/preview/audio":
                return self.send_json(preview_audio(body))
            if route == "/api/templates":
                name = str(body.get("name", "")).strip()
                if not NAME_RE.match(name):
                    return self.fail(400, "Name: letters, numbers, spaces, - and _ only")
                TEMPLATES.mkdir(parents=True, exist_ok=True)
                (TEMPLATES / f"{name}.json").write_text(
                    json.dumps(body.get("settings") or {}, indent=2))
                return self.send_json({"ok": True, "path": str(TEMPLATES / f"{name}.json")})
            if route == "/api/reveal":
                reveal(body["path"])
                return self.send_json({"ok": True})
            if route == "/api/quit":
                self.send_json({"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self.fail(404, "not found")
        except subprocess.TimeoutExpired:
            return self.fail(504, "Took too long")
        except (KeyError, ValueError, json.JSONDecodeError) as exc:
            return self.fail(400, str(exc))

    def do_DELETE(self):
        url = urlparse(self.path)
        if not self.allowed(parse_qs(url.query)):
            return
        if url.path.startswith("/api/templates/"):
            name = unquote(url.path.rsplit("/", 1)[1])
            if NAME_RE.match(name):
                (TEMPLATES / f"{name}.json").unlink(missing_ok=True)
            return self.send_json({"ok": True})
        return self.fail(404, "not found")


def main():
    global allowed_hosts
    ap = argparse.ArgumentParser(description="Levytsya local server")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    for d in (TEMPLATES, WORK, PREVIEWS):
        d.mkdir(parents=True, exist_ok=True)
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError:
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)  # port busy: pick any
    port = server.server_address[1]
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    url = f"http://127.0.0.1:{port}/"
    print(f"\n  LEVYTSYA {VERSION} is running at {url}")
    print("  Keep this window open while you use it. Press Ctrl+C to quit.\n")
    if not args.no_browser:
        threading.Timer(0.6, webbrowser.open, args=(url,)).start()

    def on_term(*_):  # the desktop app stops us with SIGTERM: clean up like Ctrl+C
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, on_term)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        job = current_job
        if job and job.state == "running":
            job.cancelled = True
            kill_tree(job.proc)
        print("\n  GAME OVER. Bye!\n", flush=True)


if __name__ == "__main__":
    main()
