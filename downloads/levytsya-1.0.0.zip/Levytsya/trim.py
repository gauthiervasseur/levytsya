#!/usr/bin/env python3
"""
trim.py: trim the beginning and end of a video and remove any number of chunks
in between, in one pass.

All timestamps are read on the ORIGINAL video's timeline (what you see when you
scrub the source file). The script turns them into a list of segments to keep
and joins those, so removing one chunk never shifts the others: no manual
recalculation needed. The plan printed before encoding shows where each join
lands in the new video.

Cuts are frame-accurate (the video is re-encoded to H.264); a 10 ms audio fade
at each join avoids clicks.

Usage:
    python trim.py talk.mp4 talk_trimmed.mp4 --start 1:05 --end 1:02:30
    python trim.py talk.mp4 out.mp4 --start 45 --cut 10:00-12:30 --cut 30:15-31:02.5
    python trim.py talk.mp4 out.mp4 --cuts-file cuts.txt --dry-run

    --start      keep from here (default: beginning)
    --end        keep until here (default: end of video)
    --cut A-B    remove A..B; repeat for each chunk, any order, overlaps are merged
    --cuts-file  text file with one "A-B" cut per line (# starts a comment)
    --dry-run    print the plan without encoding

Timestamps: SS, MM:SS or HH:MM:SS, with optional decimals (e.g. 1:02:30.5).

Requires: ffmpeg and ffprobe on PATH.
"""
import argparse
import shutil
import subprocess
import sys

FADE = 0.01  # seconds of audio fade at each join


def parse_time(text):
    try:
        parts = [float(p) for p in text.strip().split(":")]
    except ValueError:
        parts = []
    if not 1 <= len(parts) <= 3 or any(p < 0 for p in parts):
        sys.exit(f"Bad timestamp '{text}' (use SS, MM:SS or HH:MM:SS)")
    seconds = 0.0
    for p in parts:
        seconds = seconds * 60 + p
    return seconds


def fmt(seconds):
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:06.3f}"


def parse_cut(text):
    # split on the dash between the two timestamps ("10:00-12:30", "10:00 - 12:30")
    a, sep, b = text.partition("-")
    if not sep:
        sys.exit(f"Bad cut '{text}' (use START-END, e.g. 10:00-12:30)")
    start, end = parse_time(a), parse_time(b)
    if end <= start:
        sys.exit(f"Cut '{text}' ends before it starts")
    return start, end


def probe(ffprobe, path):
    def run(*args):
        return subprocess.run([ffprobe, "-v", "error", *args, "-of", "csv=p=0", path],
                              capture_output=True, text=True).stdout.strip()
    duration = run("-show_entries", "format=duration")
    if not duration:
        sys.exit(f"Cannot read {path}")
    return float(duration), bool(run("-select_streams", "a", "-show_entries",
                                     "stream=index"))


def keep_segments(start, end, cuts):
    """Original-timeline segments to keep, in order."""
    merged = []
    for a, b in sorted(cuts):
        a, b = max(a, start), min(b, end)
        if b <= a:
            continue  # cut lies entirely outside start..end
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    keep, pos = [], start
    for a, b in merged:
        if a > pos:
            keep.append((pos, a))
        pos = b
    if end > pos:
        keep.append((pos, end))
    return keep, merged


def build_filter(keep, audio):
    lines, labels = [], []
    n = len(keep)
    lines.append(f"[0:v:0]split={n}" + "".join(f"[vs{i}]" for i in range(n)))
    if audio:
        lines.append(f"[0:a:0]asplit={n}" + "".join(f"[as{i}]" for i in range(n)))
    for i, (a, b) in enumerate(keep):
        lines.append(f"[vs{i}]trim=start={a:.6f}:end={b:.6f},setpts=PTS-STARTPTS[v{i}]")
        labels.append(f"[v{i}]")
        if audio:
            fade_out = max(b - a - FADE, 0)
            lines.append(f"[as{i}]atrim=start={a:.6f}:end={b:.6f},asetpts=PTS-STARTPTS,"
                         f"afade=t=in:d={FADE},afade=t=out:st={fade_out:.6f}:d={FADE}[a{i}]")
            labels.append(f"[a{i}]")
    lines.append("".join(labels) + f"concat=n={n}:v=1:a={int(audio)}[vout]"
                 + ("[aout]" if audio else ""))
    return ";".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Trim a video and remove chunks, "
                                 "using timestamps from the original video.")
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--start", help="keep from this timestamp")
    ap.add_argument("--end", help="keep until this timestamp")
    ap.add_argument("--cut", action="append", default=[], metavar="A-B",
                    help="remove this chunk (repeatable)")
    ap.add_argument("--cuts-file", help="file with one A-B cut per line")
    ap.add_argument("--dry-run", action="store_true", help="print the plan only")
    args = ap.parse_args()

    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not (ffmpeg and ffprobe):
        sys.exit("ffmpeg and ffprobe must be on PATH")
    duration, audio = probe(ffprobe, args.input)

    start = parse_time(args.start) if args.start else 0.0
    end = min(parse_time(args.end), duration) if args.end else duration
    if end <= start:
        sys.exit(f"--end ({fmt(end)}) must be after --start ({fmt(start)})")

    cut_texts = list(args.cut)
    if args.cuts_file:
        with open(args.cuts_file) as fh:
            for line in fh:
                line = line.split("#", 1)[0].strip()
                if line:
                    cut_texts.append(line)
    keep, removed = keep_segments(start, end, [parse_cut(c) for c in cut_texts])
    if not keep:
        sys.exit("Nothing left to keep")

    total = sum(b - a for a, b in keep)
    print(f"Source: {fmt(duration)}   Result: {fmt(total)}")
    print(f"Keep {fmt(start)} -> {fmt(end)}, removing {len(removed)} chunk(s) in between")
    print(f"\n  {'#':>2}  {'original':^29}  {'in new video':^29}")
    pos = 0.0
    for i, (a, b) in enumerate(keep, 1):
        print(f"  {i:>2}  {fmt(a)} - {fmt(b)}  {fmt(pos)} - {fmt(pos + b - a)}")
        pos += b - a
    if args.dry_run:
        return

    print("\nEncoding...")
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-stats",
           "-i", args.input, "-filter_complex", build_filter(keep, audio),
           "-map", "[vout]", "-c:v", "libx264", "-crf", "18", "-preset", "medium",
           "-pix_fmt", "yuv420p"]
    if audio:
        cmd += ["-map", "[aout]", "-c:a", "aac", "-b:a", "192k"]
    cmd += ["-movflags", "+faststart", args.output]
    subprocess.run(cmd, check=True)
    print(f"Done -> {args.output}")


if __name__ == "__main__":
    main()
